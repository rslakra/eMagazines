package sample1;

import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodHandles.Lookup;
import static java.lang.invoke.MethodType.methodType;
import java.lang.reflect.Method;

/**
 * Sample 1: obtaining and calling method handles. 
 * 
 * @author Julien Ponge (julien.ponge@gmail.com)
 */
public class Sample1 {

  public static void main(String... args) throws Throwable {
    Lookup lookup = MethodHandles.lookup();

    MethodHandle startsWith = lookup.findVirtual(String.class, "startsWith",
            methodType(boolean.class, String.class));
    System.out.println(startsWith.invokeWithArguments("Java", "J"));
    System.out.println(startsWith.invokeWithArguments("Groovy", "J"));

    MethodHandle startsWithJ = MethodHandles.insertArguments(startsWith, 1, "J");
    System.out.println(startsWithJ.invokeWithArguments("Java"));
    System.out.println(startsWithJ.invokeWithArguments("Groovy"));
    
    Method startsWithMethod = String.class.getMethod("startsWith", String.class);
    startsWith = lookup.unreflect(startsWithMethod);
    System.out.println(startsWith.invokeWithArguments("Java", "J"));
    System.out.println(startsWith.invokeWithArguments("Groovy", "J"));
  }
}
