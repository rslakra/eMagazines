package sample3;

import java.lang.invoke.CallSite;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import static java.lang.invoke.MethodType.*;

/**
 * Sample 3: runtime support for an invokedynamic call site.
 * 
 * @author Julien Ponge (julien.ponge@gmail.com)
 */
public class Sample3 {

  static void printAll(String prefix, Object... values) {
    for (Object value : values) {
      System.out.println(prefix + value);
    }
  }
  
  public static CallSite bootstrap(Lookup lookup, String name, MethodType type) throws Throwable {
    MethodHandle target = lookup.findStatic(Sample3.class, "printAll", 
            methodType(void.class, String.class, Object[].class))
            .bindTo(">>> ")
            .asVarargsCollector(Object[].class)
            .asType(type);
    return new ConstantCallSite(target);
  }
  
  public static void main(String... args) throws Throwable {
    CallSite callSite = bootstrap(MethodHandles.lookup(), "printAll", methodType(void.class, Object[].class));
    callSite.dynamicInvoker().invokeWithArguments("foo", "bar", "baz");
  }
}
