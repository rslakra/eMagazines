package sample3;

import java.io.FileOutputStream;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import org.objectweb.asm.ClassWriter;
import static org.objectweb.asm.ClassWriter.*;
import org.objectweb.asm.Handle;
import org.objectweb.asm.MethodVisitor;
import static org.objectweb.asm.Opcodes.*;

/**
 * Sample 3: generate a class with invokedynamic instructions.
 * 
 * @author Julien Ponge (julien.ponge@gmail.com)
 */
public class BytecodeGenerator {

  public static void main(String... args) throws Throwable {

    ClassWriter writer = new ClassWriter(COMPUTE_MAXS | COMPUTE_FRAMES);
    writer.visit(V1_7, ACC_PUBLIC, "sample3/Caller", null, "java/lang/Object", null);

    MethodVisitor mv = writer.visitMethod(ACC_STATIC | ACC_PUBLIC, "main", "([Ljava/lang/String;)V", null, null);

    mv.visitCode();
    mv.visitLdcInsn("World");
    mv.visitLdcInsn("Hello");

    String desc = MethodType.methodType(
            CallSite.class,
            MethodHandles.Lookup.class,
            String.class,
            MethodType.class).toMethodDescriptorString();
    Handle boostrap = new Handle(H_INVOKESTATIC, "sample3/Sample3", "bootstrap", desc);
    mv.visitInvokeDynamicInsn("console:print", "(Ljava/lang/Object;Ljava/lang/Object;)V", boostrap);

    mv.visitInsn(RETURN);
    mv.visitMaxs(666, 666);
    mv.visitEnd();
    writer.visitEnd();

    FileOutputStream classOut = new FileOutputStream("build/classes/sample3/Caller.class");
    classOut.write(writer.toByteArray());
    classOut.close();
  }
}
