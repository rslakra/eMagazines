package sample2;

import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodHandles.Lookup;
import static java.lang.invoke.MethodType.*;

/**
 * Sample 2: adapting call sites of different signatures.
 * 
 * @author Julien Ponge (julien.ponge@gmail.com)
 */
public class Sample2 {

  static void printAll(String prefix, Object... values) {
    for (Object value : values) {
      System.out.println(prefix + value);
    }
  }

  public static void main(String... args) throws Throwable {
    Lookup lookup = MethodHandles.lookup();    
    MethodHandle target = lookup.findStatic(Sample2.class, "printAll", 
            methodType(void.class, String.class, Object[].class));
    MethodHandle print4 = target.bindTo(">>> ").asCollector(Object[].class, 4);    
    System.out.println(print4.type());
    print4.invokeWithArguments(1, 2, 3, 4);
  }
}
