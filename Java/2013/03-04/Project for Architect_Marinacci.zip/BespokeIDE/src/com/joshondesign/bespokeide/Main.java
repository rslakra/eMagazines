package com.joshondesign.bespokeide;

import com.sun.source.tree.CompilationUnitTree;
import com.sun.source.util.JavacTask;
import com.sun.source.util.Trees;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import javax.annotation.processing.ProcessingEnvironment;
import javax.lang.model.util.Types;
import javax.swing.*;
import javax.swing.event.CaretEvent;
import javax.swing.event.CaretListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.tools.*;

/**
 * Created by IntelliJ IDEA.
 * User: josh
 * Date: 6/20/12
 * Time: 2:53 PM
 * To change this template use File | Settings | File Templates.
 */
public class Main {
    private JTextArea methodBody;
    private JButton openButton;
    private JButton compileButton;
    private JTextArea errorConsole;
    private JPanel mainPanel;
    private JList packageList;
    private JList classList;
    private JList methodList;
    private JProgressBar progBar;
    private JLabel locationLabel;
    private JTextArea notesArea;
    private ClassModel currentClass;
    private PackageModel currentPackage;
    public CodebaseModel packages;
    private JavacTask task;
    private Trees trees;
    private MethodModel currentMethod;
    private Iterable<? extends CompilationUnitTree> ASTs;
    private ConsoleHandler consoleHandler;
    private ProcessingEnvironment env;
    private Types types;

    public Main() {

        openButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent actionEvent) {
                progBar.setIndeterminate(true);
                loadCodebase();
            }
        });

        packageList.addListSelectionListener(new ListSelectionListener() {
            public void valueChanged(ListSelectionEvent listSelectionEvent) {
                String name = (String) packageList.getSelectedValue();
                currentPackage = packages.packageMap.get(name);
                classList.setModel(new AbstractListModel() {
                    public int getSize() {
                        return currentPackage.classList.size();
                    }
                    public Object getElementAt(int i) {
                        return currentPackage.classList.get(i).name;
                    }
                });
                classList.clearSelection();
                methodList.clearSelection();
                methodList.setModel(new AbstractListModel() {
                    public int getSize() {
                        return 0;
                    }

                    public Object getElementAt(int i) {
                        return null;
                    }
                });
            }
        });
        
        classList.addListSelectionListener(new ListSelectionListener() {
            public void valueChanged(ListSelectionEvent listSelectionEvent) {
                String name = (String) classList.getSelectedValue();
                currentClass = currentPackage.classMap.get(name);
                methodList.setModel(new AbstractListModel() {
                    public int getSize() {
                        if(currentClass == null) return 0;
                        return currentClass.getMethodCount();
                    }
                    public Object getElementAt(int i) {
                        return currentClass.getMethod(i);
                    }
                });
            }
        });

        methodList.addListSelectionListener(new ListSelectionListener() {
            public void valueChanged(ListSelectionEvent listSelectionEvent) {
                if(methodList.getSelectedIndex() < 0) return;
                currentMethod = (MethodModel) methodList.getSelectedValue();
                methodBody.setText(currentMethod.body);
            }
        });
        
        methodList.setCellRenderer(new DefaultListCellRenderer(){
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
                JLabel comp = (JLabel) super.getListCellRendererComponent(
                        list, value, index, isSelected, cellHasFocus);
                if(comp != null && value != null && value instanceof MethodModel) {
                    MethodModel meth = (MethodModel) value;
                    comp.setText(meth.getUniqueName());
                }
                return comp;
            }
        });

        compileButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent actionEvent) {
                try {
                    compileCode();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });

        methodBody.addCaretListener(new CaretMoveHandler());
    }

    private void loadCodebase() {
        new Thread(new Runnable() {
            public void run() {
                try {
                    realLoadCodebase();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        }).start();
    }

    private void realLoadCodebase() throws IOException {
        consoleHandler = new ConsoleHandler(errorConsole);

        JavaCompiler compiler = ToolProvider.getSystemJavaCompiler();

        StandardJavaFileManager fileManager = compiler
                .getStandardFileManager(consoleHandler, null, null);
        fileManager.setLocation(StandardLocation.CLASS_OUTPUT,
                Arrays.asList(new File("/tmp")));


        //setup source path
        File pth = new File("/Users/josh/projects/Leo/leonardosketch.support/XMLLib/src/");
        //File pth = new File("/Users/josh/projects/Leo/LeonardoSketch/Sketch/src/");
        fileManager.setLocation(StandardLocation.SOURCE_PATH, Arrays.asList(pth));

        //get all source files
        Set<JavaFileObject.Kind> kinds = new HashSet<JavaFileObject.Kind>();
        kinds.add(JavaFileObject.Kind.SOURCE);
        Iterable<JavaFileObject> files = fileManager.list(StandardLocation.SOURCE_PATH, "", kinds, true);

        task = (JavacTask) compiler
                .getTask(null, fileManager, consoleHandler, null, null, files);

        FullCodeProcessor proc2 = new FullCodeProcessor();
        task.setProcessors(Arrays.asList(proc2));

        //task.call();
        task.setTaskListener(consoleHandler);
        //break the call() into individual pieces
        ASTs = task.parse(); //just parse the code
        task.analyze(); //fill in the types
        trees = Trees.instance(task);
        packages = proc2.getPackages(); //get the code structure back
        env = proc2.getEnv();
        types = proc2.types;

        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                packageList.setModel(new AbstractListModel() {
                    public int getSize() {
                        return packages.packageList.size();
                    }

                    public Object getElementAt(int i) {
                        return packages.packageList.get(i);
                    }
                });
                progBar.setIndeterminate(false);
            }
        });
    }

    private JavacTask setupCompiler() throws IOException {
        return (JavacTask) task;
    }

    private void compileCode() throws IOException {
        task.generate();
    }

    public static void p(String s) {
        System.out.println(s);
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Main");
        frame.setContentPane(new Main().mainPanel);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }

    private class CaretMoveHandler implements CaretListener {
        public void caretUpdate(CaretEvent caretEvent) {
            if(currentMethod == null) return;
            int dot = caretEvent.getDot(); //cursor position in characters

            CurrentMethodScanner scanner = new CurrentMethodScanner(
                    dot,
                    currentMethod,
                    trees,
                    Main.this,
                    env
                    );
            //scan every AST
            for(CompilationUnitTree ast : ASTs) {
                scanner.scan(ast,(Void)null);
            }
            locationLabel.setText(scanner.getDeepestPath());
            if(scanner.getInvokedMethod() != null) {
                notesArea.setText(scanner.getInvokedMethod().body);
            } else {
                notesArea.setText("");
            }
        }
    }
}
