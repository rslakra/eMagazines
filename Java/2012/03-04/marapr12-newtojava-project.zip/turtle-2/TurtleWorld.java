import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class TurtleWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class TurtleWorld extends World
{

    /**
     * Constructor for objects of class TurtleWorld.
     * 
     */
    public TurtleWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 400, 1); 

        prepare();
    }

    /**
     * Prepare the world for the start of the program. That is: create the initial
     * objects and add them to the world.
     */
    private void prepare()
    {
        Pizza pizza = new Pizza();
        addObject(pizza, 446, 142);
        Pizza pizza2 = new Pizza();
        addObject(pizza2, 466, 248);
        Pizza pizza3 = new Pizza();
        addObject(pizza3, 282, 361);
        Pizza pizza4 = new Pizza();
        addObject(pizza4, 122, 303);
        Pizza pizza5 = new Pizza();
        addObject(pizza5, 153, 124);
        Pizza pizza6 = new Pizza();
        addObject(pizza6, 330, 84);
        Pizza pizza7 = new Pizza();
        addObject(pizza7, 96, 210);
        Pizza pizza8 = new Pizza();
        addObject(pizza8, 503, 351);
        Turtle turtle = new Turtle();
        addObject(turtle, 287, 226);
        Snake snake = new Snake();
        addObject(snake, 96, 75);
        Snake snake2 = new Snake();
        addObject(snake2, 547, 124);
        Snake snake3 = new Snake();
        addObject(snake3, 168, 345);
    }
}
