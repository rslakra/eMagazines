public static boolean isTrue(String s) {
    String str = s.trim().toUpperCase();
    int jump = -1;
    switch(str.hashCode()) {
        case 2404:
            if (str.equals("KO")) {
                jump = 3;
            }
            break;
        case 2497:
            if (str.equals("NO")) {
                jump = 4;
            }
            break;
        case 2524:
            if (str.equals("OK")) {
                jump = 0;
            }
            break;
        case 87751:
            if (str.equals("YES")) {
                jump = 1;
            }
            break;
        case 2583950:
            if (str.equals("TRUE")) {
                jump = 2;
            }
            break;
        case 66658563:
            if (str.equals("FALSE")) {
                jump = 5;
            }
    }
    switch(jump) {
        case 0:
        case 1:
        case 2:
            return true;
        case 3:
        case 4:
        case 5:
            return false;
        default:
            throw new IllegalArgumentException("Not a valid true/false string.");
    }
}