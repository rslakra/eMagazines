public class Switch {
    
    private static void basicSwitch(int value) {
        switch (value) {            
            case 2:
                System.out.println("Number 2!");
            case 1:
            case 3:
                System.out.println("A number in the [1, 3] range: " + value);
                break;
            default:
                System.out.println("A number outside the [1, 3] range: " + value);
        }
    }
    
    static enum EmailTag { OTHER, INBOX, ACTION, HOLD, ARCHIVES, TRASH }
    
    public static void enumSwitch(EmailTag tag) {
        switch (tag) {
            case ACTION:
            case HOLD:
                System.out.println("You need to take action on this email.");
                break;
            case INBOX:
                System.out.println("You need to classify this email.");
                break;
            default:
                System.out.println("Out of the GTD scope.");
        }
    }
    
    public static boolean isTrue(String str) {
        switch(str.trim().toUpperCase()) {
            case "OK":
            case "YES":
            case "TRUE":
                return true;
            case "KO":
            case "NO":
            case "FALSE":
                return false;
            default:
                throw new IllegalArgumentException("Not a valid true/false string.");
        }
    }
    
    public static void main(String[] args) {
        basicSwitch(1);
        basicSwitch(2);
        basicSwitch(3);
        basicSwitch(4);
        System.out.println("---------------------");
        enumSwitch(EmailTag.INBOX);
        enumSwitch(EmailTag.ACTION);
        System.out.println("---------------------");
        System.out.println(isTrue(" yes "));
        System.out.println(isTrue(" no "));
    }
}