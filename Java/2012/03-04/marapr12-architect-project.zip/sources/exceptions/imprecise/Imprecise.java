public class Imprecise {

    static class SomeRootException extends Exception { }
    static class SomeChildException extends SomeRootException { }
    static class SomeOtherChildException extends SomeRootException { }
    
    public static void main(String... args) throws Throwable {
        try {
            throw new SomeChildException();
        } catch (SomeRootException firstException) {
            try {
                throw firstException;
            } catch (SomeOtherChildException secondException) {
                System.out.println("I got you!");
            }
        }
    }
}