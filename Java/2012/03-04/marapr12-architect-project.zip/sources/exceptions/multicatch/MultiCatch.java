import java.lang.reflect.*;

public class MultiCatch {
    
    static void classic() {
        try {
            Class<?> stringClass = Class.forName("java.lang.String");
            Object instance = stringClass.newInstance();
            Method toStringMethod = stringClass.getMethod("toString");
            System.out.println(toStringMethod.invoke(instance));
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }
    }
    
    static void bad() {
        try {
            Class<?> stringClass = Class.forName("java.lang.String");
            Object instance = stringClass.newInstance();
            Method toStringMethod = stringClass.getMethod("toString");
            System.out.println(toStringMethod.invoke(instance));
        } catch (Throwable t) {
            t.printStackTrace();
        }
    }
    
    static void modern() {
        try {
            Class<?> stringClass = Class.forName("java.lang.String");
            Object instance = stringClass.newInstance();
            Method toStringMethod = stringClass.getMethod("toString");
            System.out.println(toStringMethod.invoke(instance));
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException |
                 NoSuchMethodException  | InvocationTargetException e) {
            e.printStackTrace();
        }
    }
        
    public static void main(String... args) {
        classic();
        bad();
        modern();
    }
}