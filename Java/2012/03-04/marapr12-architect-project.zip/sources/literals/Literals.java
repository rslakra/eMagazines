public class Literals {

    private static void withoutUnderscores() {
        // The value 123 in decimal, octal and hexadecimal
        byte decimal = 123;
        byte octal = 0173;
        byte hexadecimal = 0x7B;
        
        // 123 in binary
        byte binary = 0b01111011;
        
        System.out.println(decimal);
        System.out.println(octal);
        System.out.println(hexadecimal);
        System.out.println(binary);
    }
    
    private static void withUnderscores() {
        // The value 123 in decimal, octal, hexadecimal and binary
        byte decimal = 123;
        byte octal = 0_173;
        byte hexadecimal = 0x7B;
        byte binary = 0b0111_1011;
        
        System.out.println(decimal);
        System.out.println(octal);
        System.out.println(hexadecimal);
        System.out.println(binary);
        
        double doubleValue = 1.111_222_444F;
        long longValue = 1_234_567_898L;
        long longHexa = 0x1234_3B3B_0123_CDEFL;
        System.out.println(doubleValue);
        System.out.println(longValue);
        System.out.println(longHexa);
    }
    
    public static void main(String[] args) {
        withoutUnderscores();
        System.out.println("--------------------");
        withUnderscores();
    }
}