import java.io.*;
import java.util.*;
import static java.util.Arrays.asList;

public class Diamond {
    
    static void verboseDeclarations() {
        List<String> strings = new LinkedList<String>();
        strings.add("hello");
        strings.add("world");
        
        Map<String, List<String>> contacts = new HashMap<String, List<String>>();
        contacts.put("Julien", new LinkedList<String>());
        contacts.get("Julien").addAll(asList("Foo", "Bar", "Baz"));
        
        System.out.println(strings);
        System.out.println(contacts);
    }
    
    static void leanerDeclarations() {
        List<String> strings = new LinkedList<>();
        strings.add("hello");
        strings.add("world");
        
        Map<String, List<String>> contacts = new HashMap<>();
        contacts.put("Julien", new LinkedList<String>());
        contacts.get("Julien").addAll(asList("Foo", "Bar", "Baz"));
        
        System.out.println(strings);
        System.out.println(contacts);
    }
    
    static void innerClasses() {
        Map<String, String> map = new HashMap<String, String>() {
            {
                put("foo", "bar");
                put("bar", "baz");
            }
        };        
        System.out.println(map);
        
        // Does not compile
        // Map<String, String> dmap = new HashMap<>() {
        //     {
        //         put("foo", "bar");
        //         put("bar", "baz");
        //     }
        // };        
        // System.out.println(dmap);
    }
    
    static class SomeClass<T extends Serializable & CharSequence> { }
    
    static void nonDenotableTypes() {
        SomeClass<?> foo = new SomeClass<String>();
        SomeClass<?> fooInner = new SomeClass<String>() { };
        
        SomeClass<?> bar = new SomeClass<>();
        // Does not compile
        // SomeClass<?> barInner = new SomeClass<>() { };
    }
    
    public static void main(String[] args) {
        verboseDeclarations();
        leanerDeclarations();
        innerClasses();
        nonDenotableTypes();
    }
}