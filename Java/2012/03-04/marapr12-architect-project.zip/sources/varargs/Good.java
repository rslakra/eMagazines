import java.util.List;
import java.util.LinkedList;

public class Good {
    
    @SafeVarargs
    private static <T> void doSomethingGood(List<T> list, T... values) {
        for (T value : values) {
            list.add(value);
        }
    }
        
    public static void main(String[] args) {
        List<String> list = new LinkedList<>();
        doSomethingGood(list, "hi", "there", "!");
    }
}