import java.util.List;
import java.util.Arrays;

public class Bad {
    
    private static <T> void doSomethingBad(List<T> list, T... values) {
        values[0] = list.get(0);
    }
    
    public static void main(String[] args) {
        List list = Arrays.asList("foo", "bar", "baz");
        doSomethingBad(list, 1, 2, 3);
    }
}