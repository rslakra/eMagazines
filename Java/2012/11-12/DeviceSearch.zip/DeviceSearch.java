
import javax.bluetooth.*;
import java.io.*;
import javax.obex.*;
import javax.microedition.io.*;

// a simple class to look for the phone bluetooth service for the backup
// if it finds it, it looks for the local data.gz file and sends it across
public class DeviceSearch implements DiscoveryListener {

  private LocalDevice localDevice;
  private DiscoveryAgent agent;

  public static void main(String args[]) {

    try {
      java.awt.EventQueue.invokeLater(new Runnable() {

        public void run() {
          Thread.yield();
          try {
            DeviceSearch browser = new DeviceSearch();
            browser.inquiry();
            Thread.yield();
            Thread.sleep(25000); // wait only 25 seconds to search and send
          } catch (Exception ex) {
            ex.printStackTrace();
          }
          Thread.yield();
        }
      });
    } catch (Exception ex) {
      ex.printStackTrace();
    }
  }

  public DeviceSearch() throws BluetoothStateException {
    localDevice = LocalDevice.getLocalDevice();
    agent = localDevice.getDiscoveryAgent();
  }

  // start looking for the local bluetooth services
  public void inquiry() throws BluetoothStateException {
    agent.startInquiry(DiscoveryAgent.GIAC, this);
  }

  // found devices
  public void deviceDiscovered(RemoteDevice device, DeviceClass devClass) {
    try {
      System.err.println("Device discovered: " + device.getFriendlyName(false));
      agent.searchServices(
              null,
              new UUID[]{new UUID(0x1105L)}, // we want the OBEX PUSH Profile
              device,
              this);

    } catch (IOException ex) {
      ex.printStackTrace();
    }
  }

  // look for the right services
  public void servicesDiscovered(int transID, ServiceRecord[] servRecord) {

	Operation op = null;
	OutputStream out = null;

    for (int i = 0; i < servRecord.length; i++) {

      String connURL = servRecord[i].getConnectionURL(
              ServiceRecord.NOAUTHENTICATE_NOENCRYPT, false);

      System.err.println(connURL);

      // found the right service?
      if (connURL.contains("5")) {

        System.err.println("Found service, connecting to it...");

        try {

          // read the local backup file
          InputStream input =
                  new BufferedInputStream(new FileInputStream("data.gz"));

          // read it in to our bucket
          byte[] bucket = new byte[32 * 1024];

          ByteArrayOutputStream result = null;

          result = new ByteArrayOutputStream(bucket.length);

          int bytesRead = 0;

          while (bytesRead != -1) {
            bytesRead = input.read(bucket);
            if (bytesRead > 0) {
              result.write(bucket, 0, bytesRead);
            }
          }

          // now - open a client session to the phone
          ClientSession clientSession =
                  (ClientSession) Connector.open(connURL);

          // connect using no headers
          HeaderSet rHeaders = clientSession.connect(null);

          if (rHeaders.getResponseCode() != ResponseCodes.OBEX_HTTP_OK) {
            // the connection could not be established
            System.err.println("Invalid header: " + rHeaders.getResponseCode());
            return;
          }

          // if we are here, then response code was ok

          byte[] sm = result.toByteArray();

          // create a new set of headers
          HeaderSet headers = clientSession.createHeaderSet();
          headers.setHeader(HeaderSet.NAME, "data.gz");
          headers.setHeader(HeaderSet.TYPE, "binary");
          headers.setHeader(HeaderSet.LENGTH, new Long(sm.length));

          // create an operation using the headers we have just created
          op = clientSession.put(headers);

          // on this operation, create the output stream
          out = op.openOutputStream();

          // and send the data
          out.write(sm);

          clientSession.disconnect(null);

        } catch (Exception ex) {
          ex.printStackTrace();
        } finally {
          try {
            out.close();
            op.close();
          } catch (Exception e) {
          }
        }

      }
    }
  }

  public void serviceSearchCompleted(int transID, int responseCode) {
    System.err.println("Service search completed");
  }

  public void inquiryCompleted(int discType) {
    System.err.println("Inquiry completed");
  }
}