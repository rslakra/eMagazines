import com.googlecode.compress_j2me.lzc.LZCInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.Date;
import java.util.Enumeration;
import javax.microedition.io.PushRegistry;
import javax.microedition.lcdui.Alert;
import javax.microedition.lcdui.AlertType;
import javax.microedition.lcdui.Choice;
import javax.microedition.lcdui.ChoiceGroup;
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.Form;
import javax.microedition.lcdui.List;
import javax.microedition.midlet.MIDlet;
import javax.microedition.rms.RecordEnumeration;
import javax.microedition.rms.RecordStore;
import javax.microedition.rms.RecordStoreException;
import javax.microedition.rms.RecordStoreNotFoundException;
import javax.microedition.pim.*;
import com.googlecode.compress_j2me.lzc.LZCOutputStream;
import java.io.ByteArrayInputStream;

public class LaunchMIDlet extends MIDlet implements CommandListener {
  
  private Display display;
  private List list;
  private Command exitCommand;
  private Command backCommand;
  private BluetoothServices btServices;
  private RecordStore rs;
  private RecordStore lrs;
  private RecordStore srs;
  
  private Alert msgAlert;
  
  private String backupDest;
  private boolean backupDestSet;
  private boolean scheduleSet;
  private String scheduleLingo;
  private long nextRun;
  
  private ChoiceGroup s1;
  
  public LaunchMIDlet() {
    
    display = Display.getDisplay(this);
    exitCommand = new Command("Exit", Command.EXIT, 1);   
    backCommand = new Command("Back", Command.BACK, 1);
    
    list = new List("Select", List.IMPLICIT);
    list.addCommand(exitCommand);
    list.setCommandListener(this);
    
    list.append("Look for destinations", null);
    list.append("Create/Edit Schedule", null);
    list.append("Do Backup Now", null);
    list.append("View Log", null);
    list.append("Do Restore Now", null);
    
    msgAlert = new Alert("Info", "", null, AlertType.INFO);
    msgAlert.setTimeout(Alert.FOREVER);
    
    // create a new Bluetooth Service class
    btServices = new BluetoothServices(display, list);    
   
    try {
      
      // load up the backup dest record store
      rs = RecordStore.openRecordStore("Backup Store", false);
      
      // this will get the last record - the last destination for our BT
      backupDest = new String(rs.getRecord(rs.getNumRecords())); 
      
      if(backupDest == null) throw new RecordStoreNotFoundException(""); 
      
      backupDestSet = true;
              
      log("Destination: " + backupDest);
      msgAlert.setString("Dest is set as: " + backupDest);
      display.setCurrent(msgAlert, list);      
      
    } catch(RecordStoreNotFoundException rsnf) {

      // we haven't setup the Backup Store yet.
      log("No Destination");
      msgAlert.setString("No destination has been set as yet");
      display.setCurrent(msgAlert, list);
      backupDestSet = false;
      
    } catch (RecordStoreException ex) {
      backupDestSet = false;
      handleError(ex);
    } finally {
      if (rs != null) try {
        rs.closeRecordStore();
      } catch (RecordStoreException ex) {
        handleError(ex);
      }
    }
    
    // next load up the record store for the schedule
    try {
      
      // load up the schedule store
      srs = RecordStore.openRecordStore("Schedule Store", true);
      
      if(srs.getNumRecords() > 0) {
        // should have only two records
        scheduleLingo = new String(srs.getRecord(1));
        nextRun = Long.parseLong(new String(srs.getRecord(2)));
     
        if(scheduleLingo != null) scheduleSet = true;
              
        log("Schedule: " + scheduleLingo);
        
      } else {
        srs.addRecord(" ".getBytes(), 0, 1);
        srs.addRecord("5000".getBytes(), 0, 1);
      }
      
    } catch(Exception ssnf) {
      nextRun = 86400000; // set to run daily in case of an error     
      ssnf.printStackTrace();
    } finally { // setup the next time the MIDlet should automatically run
      new Thread() {
        public void run() {
          try {
            PushRegistry.registerAlarm("LaunchMIDlet", 
              new Date().getTime() + nextRun);
          } catch(Exception ex) {
            ex.printStackTrace();
          }
        }
      }.start();      
    }    
    
    log("Ready");
    startBackup();

  }

  public void startApp() {    
  }
  
  public void pauseApp() {
  }
  
  public void destroyApp(boolean unconditional) {
  }

  public void commandAction(Command c, Displayable d) {
    
    if(c == backCommand) {
      display.setCurrent(list);
      return;
    }
    
    // command handler for Log actions
    if("Log Form".equals(d.getTitle())) {
      if(lrs != null) { // only dealing with the clear command here
        try {
          lrs.closeRecordStore();
          RecordStore.deleteRecordStore("Log Store");
        } catch (Exception ex) {
          ex.printStackTrace();
        } finally {
          lrs = null;
          display.setCurrent(list);
        }
      }
      return;
    }
    
    // command handler for schedule
    if("Schedule".equals(d.getTitle())) {
      
      // only one command
      // get the selected flags
      int idx1 = s1.getSelectedIndex();
      
      scheduleLingo = (idx1 == 0 ? "Daily" : "Weekly");  
      
      DataOutputStream dos = null;
      
      try {       
        
        // first set the lingo
        srs.setRecord(1, scheduleLingo.getBytes(), 0, scheduleLingo.length());
        
        // next, work out when the timer should kick off next
        // daily or weekly
        Date current = new Date();
        final long nextRun = 
          (idx1 == 0 ? 
            (current.getTime() + 86400000) : (current.getTime() + 604800000));                
        String nextRunS = (nextRun + "");
        srs.setRecord(2, nextRunS.getBytes(), 0, nextRunS.length());
        
        new Thread() {
          public void run() {
            try {
              PushRegistry.registerAlarm(
                "LaunchMIDlet", new Date().getTime() + nextRun);
            } catch(Exception ex) {
              ex.printStackTrace();
            }
          }
        }.start();
        
        
      } catch(Exception ex) {
        handleError(ex);
        return;
      } finally {
        if(dos != null) try {
          dos.close();
        } catch (IOException ex) {
          ex.printStackTrace();
        }
      }
      
      display.setCurrent(
        new Alert("Msg", "Done!", null, AlertType.INFO), list);
      
      return;

    }
    
    if (c == exitCommand) {
      destroyApp(true);
      notifyDestroyed();
    } else {
      int selectedIdx = list.getSelectedIndex();
      
      // implicit handling of the selected menu
      switch(selectedIdx) {
        case 0: { // look for destinations
          btServices.findDevices();
          break;
        }
        case 1: {
          displaySchedule();
          break;
        }
        case 2: {
          startBackup();
          break;
        }
        case 3: {
          displayLog();
          break;
        }
        case 4: {
          startRestore();
          break;
        }
        default: break;
      }
    }    
  }  

  private void displaySchedule() {
    
    Form scheduleForm = new Form("Schedule");
    scheduleForm.addCommand(backCommand);
    
    Command setSchedule = new Command("Save", Command.OK, 1);
    scheduleForm.addCommand(setSchedule);
    
    scheduleForm.setCommandListener(this);
    
    s1 = new ChoiceGroup("Daily Or Weekly", Choice.EXCLUSIVE);
    s1.append("Daily", null);
    s1.append("Weekly", null);
    
    if(scheduleSet) {
      scheduleForm.append(scheduleLingo);
    } else {
      scheduleForm.append("No Schedule Set. Set one below");
    }
    
    scheduleForm.append(s1);  
    
    display.setCurrent(scheduleForm);
    
  }

  private void startBackup() {
    
    if(backupDestSet) {
      
      // let's backup our addressbook
      try {        
        
        new Thread() {
          public void run() {
            try {
              
              log("Backup Started At: " + new Date());
              
              ByteArrayOutputStream baos = new ByteArrayOutputStream();
              LZCOutputStream os = new LZCOutputStream(baos);
              
              // the addressbook - easy to add other lists
              ContactList addressbook = 
                (ContactList)(PIM.getInstance().openPIMList(
                  PIM.CONTACT_LIST, PIM.READ_ONLY));
              
              createBackup(addressbook, PIM.CONTACT_LIST, os);
              
              btServices.doSend(backupDest, "data.gz", baos);
              
              msgAlert.setString("Done");
              display.setCurrent(msgAlert, list); 
              
              log("Backup Finished At: " + new Date());
              
            } catch (Exception ex) {
              ex.printStackTrace();
            }
          }
        }.start();       

        
      } catch (Exception ex) {
        handleError(ex);
      }
      
    } else { 
      log("Backup Destination not set. Can't backup");
      msgAlert.setString("Can't backup without a destination");
      display.setCurrent(msgAlert, list);   
      return;
    }
  }
  
  private void startRestore() {    
    log("Restore Started At: " + new Date());
    btServices.doReceive(this);    
  }
  
  void receiveBackup(byte[] data) {

    try {      
      
      // uncompress this data
      LZCInputStream lzc =
              new LZCInputStream(new ByteArrayInputStream(data));

      // decipher it
      PIMItem[] contacts =
              PIM.getInstance().fromSerialFormat(lzc, "UTF-8");

      // add to contacts - so open it up in read+write mode.
      ContactList addressbook =
              (ContactList) (PIM.getInstance().openPIMList(
              PIM.CONTACT_LIST, PIM.READ_WRITE));

      // the contacts will contain only the first vcard - this is a 
      // limitation of the fromSerialFormat method
      // left the addition of the rest of the contacts for the reader
      // as an exercise
      Contact first_contact = (Contact) contacts[0];

      // import it into the addressbook
      Contact cn = addressbook.importContact(first_contact);

      // and commit
      cn.commit();
      
      msgAlert.setString("Backup Restored!");
      
      display.setCurrent(msgAlert, list);

      log("Restore finished At: " + new Date());

    } catch (Exception ex) {
      handleError(ex);
    }


  }
  
  // creates backups and compresses them using the LZC Compression
  private void createBackup(PIMList list, int type, LZCOutputStream os) 
      throws Exception {    
        
    Enumeration e = list.items();
    
    String[] data_formats = PIM.getInstance().supportedSerialFormats(type);

    while (e.hasMoreElements()) {
      PIMItem item = (PIMItem) e.nextElement();
      PIM.getInstance().toSerialFormat(item, os, "UTF-8", data_formats[0]);
    }
    
    os.flush();   
  }

  private void displayLog() {
    if(lrs != null) {
      try {
        
        // create the display - we are only doing it here to save on startup
        // time and the user may or may not want to see the log
        Form logForm = new Form("Log Form");        
        
        Command clearCommand =  new Command("Clear Log", Command.BACK, 1);
        
        logForm.addCommand(backCommand);
        logForm.addCommand(clearCommand);        
        
        logForm.setCommandListener(this);
        
        RecordEnumeration en = lrs.enumerateRecords(null, null, false);
        while(en.hasNextElement()) {
          logForm.append(new String(en.nextRecord()));
        }
        
        display.setCurrent(logForm);
        
      } catch(Exception rns) {        
        handleError(rns);
      }
    } else {
      display.setCurrent(
        new Alert("Msg", "Log Empty", null, AlertType.ERROR), list);
    }
  }
  
  // handles errors
  private void handleError(Exception ex) {
    display.setCurrent(
      new Alert("Error!", ex.getMessage(), null, AlertType.ERROR));
    ex.printStackTrace();
  }  
  
  private void log(String msg) {
    
    if(lrs == null) {
      try {
        // load up the log store - if we can't open this it is not fatal
        lrs = RecordStore.openRecordStore("Log Store", true);
      } catch(Exception e) {
        // ignore log store exceptions
        return;
      }      
    }
    
    try {
      lrs.addRecord(
        (new Date() + " -- " + msg + "\r\n").getBytes(), 0, msg.length());
    } catch(Exception ex) {
      // ignore
      ex.printStackTrace();
    }
  }

  
}
