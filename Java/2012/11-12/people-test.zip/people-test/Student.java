/**
 * A class representing students for a simple BlueJ demo program.
 *
 * @author  Michael Kölling
 * @version 1.2, March 2012
 */
class Student extends Person
{
    private String SID;    // student ID number

    /**
     * Create a student with default settings for detail information.
     */
    public Student()
    {
        super("(unknown name)", 0000);
        SID = "(unknown ID)";
    }

    /**
     * Create a student with given name, year of birth and student ID
     */
    public Student(String name, int yearOfBirth, String studentID)
    {
        super(name, yearOfBirth);
        SID = studentID;
    }

    /**
     * Return the student ID of this student.
     */
    public String getStudentID()
    {
        return SID;
    }

    /**
     * Return the student's account name. The account name consists
     * of the first three letters of the student's name, followed by the
     * fist four letters of the student's ID.
     */
    public String getAccountName()
    {
        return getName().substring(1,3) + SID.substring(1,4);
    }

    /**
     * Return a string representation of this object.
     */
    public String toString()    // redefined from "Person"
    {
        return super.toString() +
               "Student\n" +
               "Student ID: " + SID + "\n";
    }
}

