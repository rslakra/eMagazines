create database duchess_store;

use duchess_store;

create table ADDRESS
(
	ADDRESS_ID BIGINT NOT NULL AUTO_INCREMENT, 
	PRIMARY KEY(ADDRESS_ID),
	STREET VARCHAR(250) not null,
	HOUSENUMBER VARCHAR(10) not null,
	CITY VARCHAR(250) not null,
	STATE VARCHAR(250),
	POSTCODE VARCHAR(250),
	COUNTRY VARCHAR(250) not null
);

create table ORDERLINE
(
	ORDERLINE_ID BIGINT NOT NULL AUTO_INCREMENT, 
	PRIMARY KEY(ORDERLINE_ID),
	ORDER_ID BIGINT,
	PRODUCT_ID BIGINT,
	AMOUNT NUMERIC(4) not null
);

create table ORDERS
(
	ORDER_ID BIGINT NOT NULL AUTO_INCREMENT, 
	PRIMARY KEY(ORDER_ID),
	USER_ID BIGINT,
	DISCOUNT_CODE VARCHAR(20)
);

create table PRODUCT
(
	PRODUCT_ID BIGINT NOT NULL AUTO_INCREMENT, 
	PRIMARY KEY(PRODUCT_ID),
	NAME VARCHAR(100) not null,
	DESCRIPTION VARCHAR(500),
	PRICE NUMERIC(6),
	SUPPLIES NUMERIC(5),
	TYPE VARCHAR(3)
);

create table USERS
(
	USER_ID BIGINT NOT NULL AUTO_INCREMENT, 
	PRIMARY KEY(USER_ID),
	USERNAME VARCHAR(241) not null,
	PASSWORD VARCHAR(250) not null,
	NAME VARCHAR(250) not null,
	DELIVERY_ADDRESS_ID BIGINT,
	BILLING_ADDRESS_ID BIGINT
);

create table IMAGES
(
	IMAGE_ID BIGINT NOT NULL AUTO_INCREMENT, 
	PRIMARY KEY(IMAGE_ID),
	PRODUCT_ID BIGINT,
	IMAGE_NAME VARCHAR(100)
);

alter table USERS ADD CONSTRAINT DELIVERY_ADDRESS_ID_FK Foreign Key (DELIVERY_ADDRESS_ID) references ADDRESS (ADDRESS_ID);
alter table USERS ADD CONSTRAINT BILLING_ADDRESS_ID_FK Foreign Key (BILLING_ADDRESS_ID) references ADDRESS (ADDRESS_ID);

alter table ORDERS ADD CONSTRAINT USER_ID_FK Foreign Key (USER_ID) references USERS (USER_ID);

alter table ORDERLINE ADD CONSTRAINT ORDER_ID_FK Foreign Key (ORDER_ID) references ORDERS (ORDER_ID);
alter table ORDERLINE ADD CONSTRAINT PRODUCT_ID_FK Foreign Key (PRODUCT_ID) references PRODUCT (PRODUCT_ID);

alter table IMAGES ADD CONSTRAINT PRODUCT_ID_IMG_FK Foreign Key (PRODUCT_ID) references PRODUCT (PRODUCT_ID);

insert into product (name,description,price,supplies,type) values ('Button small', 'Small Duchess button', 1, 200, NULL);
insert into product (name,description,price,supplies,type) values ('Button large', 'Large Duchess button', 400, 20, NULL);
insert into product (name,description,price,supplies,type) values ('Blue shirt L', 'Blue Duchess on Tour polo size L', 2000, 10, NULL);
insert into product (name,description,price,supplies,type) values ('Blue shirt XL', 'Blue Duchess on Tour polo size XL', 2000, 1, NULL);
insert into product (name,description,price,supplies,type) values ('Hoodie', 'White Duchess hoodie', 2000, 10, NULL);
insert into product (name,description,price,supplies,type) values ('Bag', 'Bag with Duchess logo', 1000, 25, NULL);
insert into product (name,description,price,supplies,type) values ('Keychain', 'White keychain with Duchess logo', 250, 50, NULL);
insert into product (name,description,price,supplies,type) values ('Puppet Kitt', 'Make your own Duchess Puppet kitt', 1250, 50, NULL);
INSERT INTO ADDRESS (STREET, HOUSENUMBER, CITY, STATE, POSTCODE, COUNTRY) VALUES ('Eendekamp', '38', 'Harderwijk', NULL, '3848BK', 'The Netherlands');
INSERT INTO USERS (USERNAME, PASSWORD, NAME, DELIVERY_ADDRESS_ID, BILLING_ADDRESS_ID) VALUES ('test', 'test', 'test user', 1, 1);
INSERT INTO ORDERS (USER_ID, DISCOUNT_CODE) VALUES (1, 'button2011');
INSERT INTO ORDERLINE (ORDER_ID, PRODUCT_ID, AMOUNT) VALUES (1, 1, 20);



