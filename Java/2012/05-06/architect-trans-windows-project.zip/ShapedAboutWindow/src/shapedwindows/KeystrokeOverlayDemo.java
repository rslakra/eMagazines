/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package shapedwindows;

import java.awt.AWTEvent;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.Toolkit;
import java.awt.event.AWTEventListener;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JWindow;
import javax.swing.SwingUtilities;

/**
 *
 * @author josh
 */
public class KeystrokeOverlayDemo {
    public static void main(String ... args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                KeystrokeOverlayPanel overlay = new KeystrokeOverlayPanel();
                createSampleWindow(overlay);
                createOverlay(overlay);
            }
        });
    }
    
    private static ActionListener quitAction = new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            System.exit(0);
        }
    };
    
    private static void createSampleWindow(final KeystrokeOverlayPanel overlay) {
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());
        
        //quit button
        JButton quitButton = new JButton("Quit");
        quitButton.addActionListener(quitAction);
        panel.add(quitButton,BorderLayout.EAST);
        
        //text field
        JTextField textfield = new JTextField();
        textfield.setText("type into this text field");
        panel.add(textfield, BorderLayout.CENTER);
        
        
        JFrame frame = new JFrame("Example Application");
        
        frame.add(panel);
        frame.pack();
        frame.setSize(400,70);
        frame.setVisible(true);
        frame.setLocationRelativeTo(null);
        AWTEventListener keyListener = new AWTEventListener() {
                             @Override
                             public void eventDispatched(AWTEvent event) {
                                 KeyEvent evt = (KeyEvent) event;
                                 if(evt.getID() == KeyEvent.KEY_PRESSED) {
                                     String mods = KeyEvent.getKeyModifiersText(evt.getModifiers());
                                     String keytext = mods + " " + KeyEvent.getKeyText(evt.getKeyCode());
                                     overlay.setText(keytext);
                                 }
                             }
                         };
        long mask = AWTEvent.KEY_EVENT_MASK;
        Toolkit.getDefaultToolkit().addAWTEventListener(keyListener, mask);
    }

    private static void createOverlay(KeystrokeOverlayPanel overlay) {
        JWindow window = new JWindow();
        window.add(overlay);
        window.setBackground(new Color(0,0,0,0));
        window.setAlwaysOnTop(true);
        window.pack();
        window.setSize(400,200);
        window.setVisible(true);
    }

    private static class KeystrokeOverlayPanel extends JComponent {
        private String text = "";

        public KeystrokeOverlayPanel() {
        }
        
        @Override
        public void paintComponent(Graphics gfx) {
            Graphics2D g = (Graphics2D) gfx.create();
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            //set to translucent dark gray
            g.setColor(new Color(0.2f,0.2f,0.2f,0.5f));
            g.fillRoundRect(0, 0, getWidth(), getHeight(), 40, 40);
            Font font = new Font("sansserif",Font.PLAIN,60);
            g.setFont(font);
            g.setColor(Color.WHITE);
            g.drawString(text, 50, 120);
            g.dispose();
        }

        private void setText(String keytext) {
            this.text = keytext;
            repaint();
        }
        
    }
}
