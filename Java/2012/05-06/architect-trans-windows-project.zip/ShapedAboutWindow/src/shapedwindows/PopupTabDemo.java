/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package shapedwindows;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.LinearGradientPaint;
import java.awt.Point;
import java.awt.RenderingHints;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.awt.event.WindowStateListener;
import java.awt.geom.Area;
import java.awt.geom.Path2D;
import java.awt.geom.RoundRectangle2D;
import java.awt.geom.RoundRectangle2D.Double;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JWindow;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

/**
 *
 * @author josh
 */
public class PopupTabDemo {
    public static void main(String ... args) {
        SwingUtilities.invokeLater(new Runnable(){
            @Override
            public void run() {
                try {
                    UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
                JPanel popupContents = createPopupContents();
                PopupTabComponent tab = createPopupTab(popupContents);
                createDemoWindow(tab);
            }



        });
    }
    
        private static JPanel createPopupContents() {
            JPanel panel = new JPanel();
            panel.setLayout(new BoxLayout(panel, BoxLayout.LINE_AXIS));
            panel.add(new JButton("Activate"));
            panel.add(new JButton("Disable"));
            panel.add(new JButton("Settings"));
            panel.add(new JButton("..."));
            return panel;
        }

    private static void createDemoWindow(final PopupTabComponent tab) {
        final JFrame frame = new JFrame("App with popup");
        JButton button = new JButton("Cilck this button.");
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tab.showTab(frame);
            }
        });
        frame.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentMoved(ComponentEvent e) {
                tab.hideTab();
            }
        });
        frame.addWindowListener(new WindowAdapter() {

            @Override
            public void windowClosed(WindowEvent e) {
                tab.hideTab();
            }

            @Override
            public void windowIconified(WindowEvent e) {
                tab.hideTab();
            }

            @Override
            public void windowDeactivated(WindowEvent e) {
                tab.hideTab();
            }
        });
        frame.add(button);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        frame.setSize(300, 100);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
            
    private static PopupTabComponent createPopupTab(JComponent contents) {
        PopupTabComponent tabComponent = new PopupTabComponent(contents);
        JWindow window = new JWindow();
        window.setBackground(new Color(0,0,0,0));
        window.setAlwaysOnTop(true);
        window.add(tabComponent);
        window.pack();
        window.setSize(300,100);
        window.setVisible(false);
        return tabComponent;
    }

    private static class PopupTabComponent extends JComponent {

        public PopupTabComponent(JComponent component) {
            this.setLayout(new BorderLayout());
            this.add(component, BorderLayout.CENTER);
            component.setBackground(new Color(0,0,0,0));
            this.setBorder(BorderFactory.createEmptyBorder(35, 10, 10, 10));
        }

        @Override
        protected void paintComponent(Graphics gfx) {
            Graphics2D g = (Graphics2D) gfx;
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            
            Color[] colors = new Color[]{
                           new Color(0.6f,.6f,.6f,0.9f)
                            ,new Color(0.9f,0.9f,0.9f,1f)
                            ,new Color(0.9f,0.9f,0.9f,1f)
                            ,new Color(0.6f,0.6f,0.6f,0.9f)};
            float[] stops = new float[]{0.2f,0.4f,0.9f,1f};
            LinearGradientPaint paint = new LinearGradientPaint(
                                        new Point(0,0), new Point(0,getHeight()),
                                        stops,colors);
            
            
            //g.setPaint(new Color(255,255,255,120));
            g.setPaint(paint);
            Path2D.Double path = new Path2D.Double();
            path.moveTo(getWidth()/2, 0);
            path.lineTo(getWidth()/2+20, 30);
            path.lineTo(getWidth()/2-20, 30);
            path.closePath();
            Area area = new Area(path);
            RoundRectangle2D.Double rect = new RoundRectangle2D.Double(0,30,getWidth()-1,getHeight()-30-1,30,30);
            area.add(new Area(rect));
            
            g.fill(area);
            g.setPaint(new Color(50,50,50,120));
            g.draw(area);
            
        }

        private void showTab(JFrame frame) {
            Window window = (Window) this.getRootPane().getParent();
            int x = frame.getX()+frame.getWidth()/2 - window.getWidth()/2;
            int y = frame.getY() + frame.getHeight();
            window.setLocation(x,y);
            window.setVisible(true);                    
        }

        private void hideTab() {
            Window window = (Window) this.getRootPane().getParent();
            window.setVisible(false);
        }
        
        
    }
}
