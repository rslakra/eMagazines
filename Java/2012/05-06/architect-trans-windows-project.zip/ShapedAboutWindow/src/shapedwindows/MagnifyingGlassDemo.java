/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package shapedwindows;

import java.awt.AWTException;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.Robot;
import java.awt.Shape;
import java.awt.Window;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.geom.Area;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.event.MouseInputAdapter;

/**
 *
 * @author josh
 */
public class MagnifyingGlassDemo extends JPanel {

    public static void main(String... args) {
        SwingUtilities.invokeLater(new Runnable() {

            @Override
            public void run() {
                try {
                    JFrame frame = new JFrame();
                    frame.setUndecorated(true);
                    frame.setBackground(new Color(0, 0, 0, 0));
                    MagnifyingGlassDemo main = new MagnifyingGlassDemo();
                    main.frame = frame;
                    frame.setContentPane(main);
                    //frame.getRootPane().putClientProperty("apple.awt.draggableWindowBackground", false);
                    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                    frame.pack();
                    frame.setSize(450, 535);
                    frame.setVisible(true);
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
        });

    }
    private static final Rectangle magArea = new Rectangle(223, 50, 37, 37);
    private static final Point2D.Double bigOffset = new Point2D.Double(80, 140);
    private static final float mag = 9f;
    public JFrame frame;
    private BufferedImage screen = new BufferedImage(magArea.width, magArea.height, BufferedImage.TYPE_INT_ARGB);
    private BufferedImage bgImage;

    public MagnifyingGlassDemo() throws IOException {
        MoveMouseListener ml = new MoveMouseListener(this);
        this.addMouseListener(ml);
        this.addMouseMotionListener(ml);
        this.setOpaque(false);
        bgImage = ImageIO.read(MagnifyingGlassDemo.class.getResource("template.png"));
    }

    @Override
    protected void paintComponent(Graphics graphics) {
        super.paintComponent(graphics);
        Graphics2D g = (Graphics2D) graphics;
        g = (Graphics2D) g.create();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        Ellipse2D small = new Ellipse2D.Double(magArea.x - 1, magArea.y - 1, magArea.width + 2, magArea.height + 2);
        Ellipse2D big = new Ellipse2D.Double(bigOffset.getX(), bigOffset.getY(), magArea.width * mag - 10, magArea.height * mag - 10);
        double smallStroke = 2;
        Area area = new Area();
        area.add(new Area(new Rectangle2D.Double(
                small.getX() + small.getWidth() / 2 - smallStroke,
                10 - smallStroke,
                big.getX() + big.getWidth() / 2,
                big.getY() + big.getHeight() / 2)));
        area.add(new Area(new Rectangle2D.Double(
                10 - smallStroke * 1,
                small.getY() + small.getHeight() / 2,
                big.getX() + big.getWidth() / 2,
                big.getY() + big.getHeight() / 2)));

        area.subtract(new Area(small));
        area.subtract(new Area(big));

        g.setPaint(Color.DARK_GRAY);
        g.setStroke(new BasicStroke(2));
        Shape oldClip = g.getClip();
        g.setClip(big);
        g.drawImage(screen, (int) bigOffset.getX(), 130, (int) (magArea.width * mag), (int) (magArea.height * mag), null);
        g.setClip(oldClip);
        g.drawImage(bgImage, 0, 0, null);
        g.dispose();
    }

    void updateScreenshot() {
        try {
            Point pt = new Point(magArea.x, magArea.y);
            SwingUtilities.convertPointToScreen(pt, MagnifyingGlassDemo.this);
            Robot robot = new Robot();
            screen = robot.createScreenCapture(new Rectangle(pt.x, pt.y, magArea.width, magArea.height));
            repaint();
        } catch (AWTException ex) {
            ex.printStackTrace();
        }
    }

    class MoveMouseListener extends MouseInputAdapter {
        JComponent target;
        Point start_drag;
        Point start_loc;

        public MoveMouseListener(JComponent target) {
            this.target = target;
        }

        public void mousePressed(MouseEvent e) {
            this.start_drag = this.getScreenLocation(e.getPoint());
            this.start_loc = this.getScreenLocation(new Point(0, 0));
        }

        public void mouseDragged(MouseEvent e) {
            Point current = this.getScreenLocation(e.getPoint());
            Point offset = new Point(
                    (int) current.getX() - (int) start_drag.getX(),
                    (int) current.getY() - (int) start_drag.getY());
            Point new_location = new Point(
                    (int) (this.start_loc.getX() + offset.getX()),
                    (int) (this.start_loc.getY() + offset.getY()));
            Window window = SwingUtilities.getWindowAncestor(target);
            window.setLocation(new_location);
            updateScreenshot();
        }

        protected Point getScreenLocation(Point e) {
            Point pt = new Point(e.x, e.y);
            SwingUtilities.convertPointToScreen(pt, target);
            return pt;
        }
    }
}
