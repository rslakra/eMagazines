/*
 * BindingExampleMain - Located in the BindingExampleExercise project, this
 * program demonstrates JavaFX properties and binding concepts
 * Developed Nov 2011 by Jim Weaver
 */
package javafxpert.ui;

import javafx.application.Application;
import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.SceneBuilder;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class BindingExampleMain extends Application {

  public static void main(String[] args) {
    Application.launch(args);
  }
  
  @Override
  public void start(Stage primaryStage) {
    
    // Demonstrate InvalidationListener 
    Label sliderLabelA = new Label("InvalidationListener");
    GridPane.setConstraints(sliderLabelA, 0, 0);
    
    final DoubleProperty valueA = new SimpleDoubleProperty(0);
    
    Slider sliderA = SliderBuilder.create()
      .max(100)
      .build();
    sliderA.valueProperty().bindBidirectional(valueA);
    GridPane.setConstraints(sliderA, 1, 0);

    final Label labelA = new Label("0.0");
    GridPane.setConstraints(labelA, 3, 0);
    
    valueA.addListener(new InvalidationListener() {
      public void invalidated(Observable observable) {
        // observable is a DoubleProperty
        // TO DO: Cast the Observable object to a DoubleProperty, get its value
        //        and convert it to a String, and set the text of
        //        labelA to the String.
      
      }
    });
    
    // Demonstrate ChangeListener 
    Label sliderLabelB = new Label("ChangeListener");
    GridPane.setConstraints(sliderLabelB, 0, 1);
    
    final DoubleProperty valueB = new SimpleDoubleProperty(0);
    
    Slider sliderB = SliderBuilder.create()
      .max(100)
      .build();
    sliderB.valueProperty().bindBidirectional(valueB);
    GridPane.setConstraints(sliderB, 1, 1);

    final Label labelB = new Label("0.0");
    GridPane.setConstraints(labelB, 3, 1);
    
    valueB.addListener(new ChangeListener() {
      public void changed(ObservableValue ov, 
                          Object oldValue, Object newValue) {
        // ov is a DoubleProperty, and newValue is a Double
        // TO DO: Convert the newValue to a String and set the value of the
        //        text property of labelB to the String.
      
      }
    });
    
    // Demonstrate bind/unbind 
    Label sliderLabelC = new Label("bind/unbind");
    GridPane.setConstraints(sliderLabelC, 0, 2);
    
    final DoubleProperty valueC = new SimpleDoubleProperty(0);
    
    Slider sliderC = SliderBuilder.create()
      .max(100)
      .build();
    sliderC.valueProperty().bindBidirectional(valueC);
    GridPane.setConstraints(sliderC, 1, 2);
    
    final Label labelC = new Label();
    GridPane.setConstraints(labelC, 3, 2);
    
    CheckBox checkBoxC = CheckBoxBuilder.create()
      .text("Bind")
      .selected(false)
      .build();
    checkBoxC.selectedProperty().addListener(new ChangeListener<Boolean>() {
      public void changed(ObservableValue ov, 
                          Boolean oldValue, Boolean newValue) {
        if (newValue.booleanValue()) {
          
          // TO DO: Using the bind() method and the Fluent API, bind the text 
          // property of labelC to the product of valueA and valueB plus valueC
        
        }
        else {
          labelC.textProperty().unbind();
        }
      }
    });
    GridPane.setConstraints(checkBoxC, 2, 2);
    
    Scene scene = SceneBuilder.create()
      .width(500)
      .height(150)
      .root(
        GridPaneBuilder.create()
          .hgap(10)
          .vgap(10)
          .padding(new Insets(20, 10, 10, 20))
          .children(
            sliderLabelA,
            sliderA,
            labelA,
            sliderLabelB,
            sliderB,
            labelB,
            sliderLabelC,
            sliderC,
            checkBoxC,
            labelC
          )
          .build()
      )
      .build();
    
    primaryStage.setTitle("Binding Example: Exercise");
    primaryStage.setScene(scene);
    primaryStage.show();
  }
}
