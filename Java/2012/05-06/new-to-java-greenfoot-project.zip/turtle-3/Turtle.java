import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Turtle here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Turtle extends Actor
{
    /**
     * Act: move around (keyboard controlled) and eat pizza
     * if we find any.
     */
    public void act() 
    {
        moveAndTurn();
        eat();
    }
    
    /**
     * Move forward and turn if the control keys are pressed.
     */
    public void moveAndTurn()
    {
        move(4);

        if(Greenfoot.isKeyDown("left")) {
            turn(-3);
        }

        if(Greenfoot.isKeyDown("right")) {
            turn(3);
        }
    }
    
    /**
     * Look for pizza and eat it if we see some.
     */
    public void eat()
    {
        Actor pizza = getOneIntersectingObject(Pizza.class);
        if(pizza != null) {
            getWorld().removeObject(pizza);
            Greenfoot.playSound("slurp.wav");
        }
    }
}
