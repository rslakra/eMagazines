
import javax.microedition.location.Location;
import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import javax.microedition.media.*;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import javax.microedition.io.Connector;
import javax.microedition.io.file.FileConnection;
import javax.microedition.location.Criteria;
import javax.microedition.location.LocationListener;
import javax.microedition.location.LocationProvider;
import javax.microedition.location.QualifiedCoordinates;
import javax.microedition.media.control.VideoControl;
import rext.simpleexif.EXIFReader;

public class CameraMidlet extends MIDlet
        implements CommandListener, LocationListener {

  // initialize the player and the canvas
  private CaptureVideoCanvas canvas = null;
  Player capturePlayer = null;
  // and the other variables
  private Alert alert = null;
  private Command exitCommand = null;
  Display display = null;
  private boolean error = false;
  // the current location  
  private Location currentLocation = null;

  public CameraMidlet() {

    // create the display items
    alert = new Alert("Message");
    display = Display.getDisplay(this);
    exitCommand = new Command("Exit", Command.EXIT, 1);

    // create the video capture player
    try {
      capturePlayer = Manager.createPlayer("capture://video");
      capturePlayer.realize();

      // now create the canvas
      canvas = new CaptureVideoCanvas(this);
      canvas.addCommand(exitCommand);
      canvas.setCommandListener(this);

      // now load up the location data code

      // create a very basic criteria for the provider
      Criteria criteria = new Criteria();
      criteria.setHorizontalAccuracy(Criteria.NO_REQUIREMENT);
      criteria.setVerticalAccuracy(Criteria.NO_REQUIREMENT);
      criteria.setPreferredResponseTime(Criteria.NO_REQUIREMENT);
      criteria.setCostAllowed(false);

      // get the provider based on this criteria
      LocationProvider provider = LocationProvider.getInstance(criteria);

      // provider found
      if (provider != null) {
        provider.setLocationListener(this, -1, 0, 0);
      } else {
        error = true;
        display.setCurrent(
                new Alert("Error!",
                "Phone does not support Location Provider with the given criteria",
                null, AlertType.ERROR));
      }

    } catch (Exception e) {
      handleError(e);
    }
  }

  public void startApp() {

    // if error, return
    if (error) {
      return;
    }

    // start the player
    try {
      capturePlayer.start();
    } catch (Exception e) {
      handleError(e);
    }

    // and set the canvas as the current item on display
    display.setCurrent(canvas);
  }

  public void pauseApp() {
    try {
      if (capturePlayer != null) {
        capturePlayer.stop();
      }
    } catch (Exception e) {
    }
  }

  public void destroyApp(boolean unconditional) {
    if (capturePlayer != null) {
      capturePlayer.close();
    }
  }

  public void commandAction(Command cmd, Displayable disp) {
    if (cmd == exitCommand) {
      destroyApp(true);
      notifyDestroyed();
    }
  }

  // general purpose error method, displays on screen as well to output
  void handleError(Exception e) {
    alert.setString(e.getMessage());
    alert.setTitle("Error");
    display.setCurrent(alert);
    e.printStackTrace();
    error = true;
  }

  // general purpose method to show a message
  void showMessage(String msg) {
    alert.setString(msg);
    alert.setTitle("Info");
    display.setCurrent(alert);
  }

  // handle any location updates
  public void locationUpdated(LocationProvider lp, Location location) {

    // if valid location is found, update the coords and status
    if (location != null && location.isValid()) {
      currentLocation = location;
    } else {
      currentLocation = null;
    }

  }

  // returns the current location
  public Location getCurrentLocation() {
    return this.currentLocation;
  }

  public void providerStateChanged(LocationProvider lp, int i) {
    // not implemented
  }
}

// the class that holds the video canvas
class CaptureVideoCanvas extends Canvas {

  // the base midlet
  CameraMidlet midlet = null;
  // the video control
  private VideoControl videoControl = null;
  // the output stream
  ByteArrayOutputStream bos = null;
  // the captured image
  Image image;

  public CaptureVideoCanvas(CameraMidlet midlet)
          throws Exception {

    this.midlet = midlet;

    // initialize the video control
    videoControl =
            (VideoControl) midlet.capturePlayer.getControl(
            "javax.microedition.media.control.VideoControl");

    // if not present, throw error
    if (videoControl == null) {
      throw new Exception("No Video Control for capturing!");
    }

    // init display mode to use direct video and this canvas
    videoControl.initDisplayMode(VideoControl.USE_DIRECT_VIDEO, this);

    try { // try and set to full screen
      videoControl.setDisplayFullScreen(true);
    } catch (MediaException me) {

      // but some devices may not support full screen mode
      videoControl.setDisplayLocation(5, 5);
      try {
        videoControl.setDisplaySize(getWidth() - 10, getHeight() - 10);
      } catch (Exception e) {
      }

      repaint();
    }

    // and make the video control visible
    videoControl.setVisible(true);
  }

  // private method to reduce the display of lat and lng to three deimcal places
  private static double truncate(double x) {

    if (x > 0) {
      return Math.floor(x * 100) / 100;
    } else {
      return Math.ceil(x * 100) / 100;
    }

  }

  public void keyPressed(int keyCode) {

    // see what game action key the user has pressed
    int key = getGameAction(keyCode);

    // if fire, take a snapshot
    if (key == FIRE) {

      // hold our latitude and longitude here
      final double lat;
      final double lng;

      // do we have a valid current location?
      if (midlet.getCurrentLocation() != null) {
        QualifiedCoordinates coords =
                midlet.getCurrentLocation().getQualifiedCoordinates();

        lat = truncate(coords.getLatitude());
        lng = truncate(coords.getLongitude());

      } else {
        midlet.showMessage("Sorry, Location data not found!");
        return;
      }

      // all good.. let's modify the image to hold the EXIF data
      try {


        // use the control to take the picture, using the default encoding
        // in a separate thread

        new Thread() {

          // hold the original image array data
          byte[] imageArray;
          // and this for the modified array data
          byte[] modArray;

          public void run() {

            try {

              // take the picture
              imageArray = videoControl.getSnapshot("encoding=jpeg");

              // read it              
              ByteArrayInputStream bis = new ByteArrayInputStream(imageArray);

              // for writing the modified array
              ByteArrayOutputStream bos = new ByteArrayOutputStream();

              int bite;
              int location = 0;

              // now read through the image data
              while ((bite = bis.read()) != -1) {

                // and when we get to location 3 we start changing and then 
                // adding our own EXIF data
                if (location == 3) {

                  // replace OxE0 - from APP0 to APP1
                  bos.write(0xE1);
                  bos.write(0x00);

                  // total size (100)
                  bos.write(0x64);

                  // EXIF Header - 6 bytes
                  bos.write("Exif".getBytes(), 0, 4);
                  bos.write(0x00);
                  bos.write(0x00);

                  // TIFF Header - 8 bytes
                  bos.write("II*".getBytes(), 0, 3);
                  bos.write(0x00);

                  bos.write(0x08);
                  bos.write(0x00);
                  bos.write(0x00);
                  bos.write(0x00);

                  // number of directory entries for first IFD - 2 bytes
                  bos.write(0x01);
                  bos.write(0x00);

                  // GPS IFD tag number - 2 bytes
                  bos.write(0x25);
                  bos.write(0x88);

                  // data format (unsigned long integer) - 2 bytes
                  bos.write(0x04);
                  bos.write(0x00);

                  // number of components (1) - 4 bytes
                  bos.write(0x01);
                  bos.write(0x00);
                  bos.write(0x00);
                  bos.write(0x00);

                  // offset to GPS IFD start - data value (26) - 4 bytes
                  bos.write(0x1A);
                  bos.write(0x00);
                  bos.write(0x00);
                  bos.write(0x00);

                  // end of the directory entries - 4 bytes;
                  bos.write(0x00);
                  bos.write(0x00);
                  bos.write(0x00);
                  bos.write(0x00);

                  // link from GPS Info ID 

                  // we have 3 entries here (version, lat and long) - 2 bytes
                  bos.write(0x03);
                  bos.write(0x00);

                  // first entry is GPS Version tag number -- 2 bytes
                  bos.write(0x00);
                  bos.write(0x00);

                  // data format (ascii) - 2 bytes
                  bos.write(0x02);
                  bos.write(0x00);

                  // number of components (1) - 4 bytes
                  bos.write(0x01);
                  bos.write(0x00);
                  bos.write(0x00);
                  bos.write(0x00);

                  // data value (2200) - 4 bytes
                  bos.write(0x32);
                  bos.write(0x32);
                  bos.write(0x30);
                  bos.write(0x30);

                  // second entry is GPS Latitude -- 2 bytes
                  bos.write(0x02);
                  bos.write(0x00);

                  // data format (rational) - 2 bytes
                  bos.write(0x05);
                  bos.write(0x00);

                  // number of components (2 - degress and minutes) - 4 bytes
                  bos.write(0x02);
                  bos.write(0x00);
                  bos.write(0x00);
                  bos.write(0x00);

                  // offset to data value (64) - 4 bytes
                  bos.write(0x40);
                  bos.write(0x00);
                  bos.write(0x00);
                  bos.write(0x00);

                  // third entry is GPS Longitude -- 2 bytes
                  bos.write(0x04);
                  bos.write(0x00);

                  // data format (rational) - 2 bytes
                  bos.write(0x05);
                  bos.write(0x00);

                  // number of components (1) - 4 bytes
                  bos.write(0x02);
                  bos.write(0x00);
                  bos.write(0x00);
                  bos.write(0x00);

                  // offset to data value () - 4 bytes
                  bos.write(0x50);
                  bos.write(0x00);
                  bos.write(0x00);
                  bos.write(0x00);

                  // actual data linked to from offsets
                  // first 16 bytes are for gps latitude - 8 for deg/8 for min
                  // last 16 bytes are for gps longitude

                  // data is expressed as a rational 
                  // so first 4 bytes are the numerator, last 4 bytes are 
                  // the denominator and is always 1
                  
                  // but first, convert lat and lng to degrees and minutes
                  int[] lat_in_deg = convert(lat);
                  bos.write(lat_in_deg[0]);                  
                  bos.write(0x00);
                  bos.write(0x00);
                  bos.write(0x00);

                  bos.write(0x01);
                  bos.write(0x00);
                  bos.write(0x00);
                  bos.write(0x00);

                  // end gps lat degrees
                  // start gps lat minutes

                  bos.write(lat_in_deg[1]);
                  bos.write(0x00);
                  bos.write(0x00);
                  bos.write(0x00);

                  bos.write(0x01);
                  bos.write(0x00);
                  bos.write(0x00);
                  bos.write(0x00);

                  // end gps lat minutes
                  // start gps lng degrees
                  int[] lng_in_deg = convert(lng);
                  bos.write(lng_in_deg[0]);
                  bos.write(0x00);
                  bos.write(0x00);
                  bos.write(0x00);

                  bos.write(0x01);
                  bos.write(0x00);
                  bos.write(0x00);
                  bos.write(0x00);

                  // end gps lat degrees
                  // start gps lat minutes

                  bos.write(lng_in_deg[1]);
                  bos.write(0x00);
                  bos.write(0x00);
                  bos.write(0x00);

                  bos.write(0x01);
                  bos.write(0x00);
                  bos.write(0x00);
                  bos.write(0x00);

                  // end gps lng minutes

                  // end - 4 bytes
                  bos.write(0x00);
                  bos.write(0x00);
                  bos.write(0x00);
                  bos.write(0x00);

                  // 100                 

                  location++;
                  continue;
                }

                bos.write(bite);
                location++;
              }

              // this is our modified array
              modArray = bos.toByteArray();

              repaint();
              
              // EXIFReader r = new EXIFReader();
              // r.readEXIFFromByteArry(modArray);
              
            } catch (Exception e) {
              midlet.handleError(e);
            }
            
            // store this image in the file system
            String dirPhotos = System.getProperty("fileconn.dir.photos");
            if (dirPhotos == null) {
              midlet.handleError(new Exception("Dir cannot be found"));
              return;
            }

            try {

              String fileName = 
                dirPhotos + new java.util.Date().getTime() + ".jpg";

              // Open file
              FileConnection file = (FileConnection) Connector.open(fileName,
                      Connector.READ_WRITE);

              // If there is no file then create it
              if (file.exists() == false) {
                file.create();
              }

              OutputStream outStream = file.openOutputStream();
              outStream.write(modArray);
              
              midlet.showMessage("Image is saved in " + fileName);             
              

            } catch (IOException iex) {
              midlet.handleError(iex);
            }

          }
        }.start();

      } catch (Exception e) {
        midlet.handleError(e);
      }
    } else {
      // ignore all other keys
    }
  }
  
  // private method to convert the long/lat into
  // separate rational entities  
  private int[] convert(double val) {
    
    int deg = (int)val; // deg is the integer part of the double value
    int min = (int)((val - deg) * 60); // min is the fractional part * 60
    
    return new int[] {deg, min};    
  }

  public void paint(Graphics g) {

    // clear background
    g.setColor(0xffffff);
    g.fillRect(0, 0, getWidth(), getHeight());

    // draw any image found
    if (image != null) {
      videoControl.setVisible(false);
      g.drawImage(image, 0, 0, Graphics.TOP | Graphics.LEFT);
    } else {
      g.setColor(0x44ff66);
      g.drawRect(2, 2, getWidth() - 4, getHeight() - 4);
    }
  }
}
