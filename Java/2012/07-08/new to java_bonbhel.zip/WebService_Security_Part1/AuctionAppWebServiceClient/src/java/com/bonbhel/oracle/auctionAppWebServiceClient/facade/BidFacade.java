/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.bonbhel.oracle.auctionAppWebServiceClient.facade;

import com.bonbhel.oracle.auctionAppWebServiceClient.Bid;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author bonbhejf
 */
@Stateless
public class BidFacade extends AbstractFacade<Bid> {
    @PersistenceContext(unitName = "AuctionAppWebServiceClientPU")
    private EntityManager em;

    protected EntityManager getEntityManager() {
        return em;
    }

    public BidFacade() {
        super(Bid.class);
    }
    
}
