/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.bonbhel.oracle.auctionApp.converter;

import com.bonbhel.oracle.auctionApp.Bid;
import java.net.URI;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlAttribute;
import javax.ws.rs.core.UriBuilder;
import javax.persistence.EntityManager;
import com.bonbhel.oracle.auctionApp.Item;

/**
 *
 * @author bonbhejf
 */

@XmlRootElement(name = "bid")
public class BidConverter {
    private Bid entity;
    private URI uri;
    private int expandLevel;
  
    /** Creates a new instance of BidConverter */
    public BidConverter() {
        entity = new Bid();
    }

    /**
     * Creates a new instance of BidConverter.
     *
     * @param entity associated entity
     * @param uri associated uri
     * @param expandLevel indicates the number of levels the entity graph should be expanded@param isUriExtendable indicates whether the uri can be extended
     */
    public BidConverter(Bid entity, URI uri, int expandLevel, boolean isUriExtendable) {
        this.entity = entity;
        this.uri = (isUriExtendable) ? UriBuilder.fromUri(uri).path(entity.getId() + "/").build() : uri;
        this.expandLevel = expandLevel;
        getItem();
    }

    /**
     * Creates a new instance of BidConverter.
     *
     * @param entity associated entity
     * @param uri associated uri
     * @param expandLevel indicates the number of levels the entity graph should be expanded
     */
    public BidConverter(Bid entity, URI uri, int expandLevel) {
        this(entity, uri, expandLevel, false);
    }

    /**
     * Getter for id.
     *
     * @return value for id
     */
    @XmlElement
    public Long getId() {
        return (expandLevel > 0) ? entity.getId() : null;
    }

    /**
     * Setter for id.
     *
     * @param value the value to set
     */
    public void setId(Long value) {
        entity.setId(value);
    }

    /**
     * Getter for amount.
     *
     * @return value for amount
     */
    @XmlElement
    public Double getAmount() {
        return (expandLevel > 0) ? entity.getAmount() : null;
    }

    /**
     * Setter for amount.
     *
     * @param value the value to set
     */
    public void setAmount(Double value) {
        entity.setAmount(value);
    }

    /**
     * Getter for bidderName.
     *
     * @return value for bidderName
     */
    @XmlElement
    public String getBidderName() {
        return (expandLevel > 0) ? entity.getBidderName() : null;
    }

    /**
     * Setter for bidderName.
     *
     * @param value the value to set
     */
    public void setBidderName(String value) {
        entity.setBidderName(value);
    }

    /**
     * Getter for item.
     *
     * @return value for item
     */
    @XmlElement
    public ItemConverter getItem() {
        if (expandLevel > 0) {
            if (entity.getItem() != null) {
                return new ItemConverter(entity.getItem(), uri.resolve("item/"), expandLevel - 1, false);
            }
        }
        return null;
    }

    /**
     * Setter for item.
     *
     * @param value the value to set
     */
    public void setItem(ItemConverter value) {
        entity.setItem((value != null) ? value.getEntity() : null);
    }

    /**
     * Returns the URI associated with this converter.
     *
     * @return the uri
     */
    @XmlAttribute
    public URI getUri() {
        return uri;
    }

    /**
     * Sets the URI for this reference converter.
     *
     */
    public void setUri(URI uri) {
        this.uri = uri;
    }

    /**
     * Returns the Bid entity.
     *
     * @return an entity
     */
    @XmlTransient
    public Bid getEntity() {
        if (entity.getId() == null) {
            BidConverter converter = UriResolver.getInstance().resolve(BidConverter.class, uri);
            if (converter != null) {
                entity = converter.getEntity();
            }
        }
        return entity;
    }

    /**
     * Returns the resolved Bid entity.
     *
     * @return an resolved entity
     */
    public Bid resolveEntity(EntityManager em) {
        Item item = entity.getItem();
        if (item != null) {
            entity.setItem(em.getReference(Item.class, item.getId()));
        }
        return entity;
    }
}
