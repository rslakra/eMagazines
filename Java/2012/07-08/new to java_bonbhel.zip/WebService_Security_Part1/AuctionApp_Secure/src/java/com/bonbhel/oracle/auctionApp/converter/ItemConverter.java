/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.bonbhel.oracle.auctionApp.converter;

import com.bonbhel.oracle.auctionApp.Item;
import java.net.URI;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlAttribute;
import javax.ws.rs.core.UriBuilder;
import javax.persistence.EntityManager;
import com.bonbhel.oracle.auctionApp.Bid;
import java.util.List;
import com.bonbhel.oracle.auctionApp.Seller;

/**
 *
 * @author bonbhejf
 */

@XmlRootElement(name = "item")
public class ItemConverter {
    private Item entity;
    private URI uri;
    private int expandLevel;
  
    /** Creates a new instance of ItemConverter */
    public ItemConverter() {
        entity = new Item();
    }

    /**
     * Creates a new instance of ItemConverter.
     *
     * @param entity associated entity
     * @param uri associated uri
     * @param expandLevel indicates the number of levels the entity graph should be expanded@param isUriExtendable indicates whether the uri can be extended
     */
    public ItemConverter(Item entity, URI uri, int expandLevel, boolean isUriExtendable) {
        this.entity = entity;
        this.uri = (isUriExtendable) ? UriBuilder.fromUri(uri).path(entity.getId() + "/").build() : uri;
        this.expandLevel = expandLevel;
        getBids();
        getSeller();
    }

    /**
     * Creates a new instance of ItemConverter.
     *
     * @param entity associated entity
     * @param uri associated uri
     * @param expandLevel indicates the number of levels the entity graph should be expanded
     */
    public ItemConverter(Item entity, URI uri, int expandLevel) {
        this(entity, uri, expandLevel, false);
    }

    /**
     * Getter for bids.
     *
     * @return value for bids
     */
    @XmlElement
    public BidsConverter getBids() {
        if (expandLevel > 0) {
            if (entity.getBids() != null) {
                return new BidsConverter(entity.getBids(), uri.resolve("bids/"), expandLevel - 1);
            }
        }
        return null;
    }

    /**
     * Setter for bids.
     *
     * @param value the value to set
     */
    public void setBids(BidsConverter value) {
        entity.setBids((value != null) ? new java.util.ArrayList<Bid>(value.getEntities()) : null);
    }

    /**
     * Getter for id.
     *
     * @return value for id
     */
    @XmlElement
    public Long getId() {
        return (expandLevel > 0) ? entity.getId() : null;
    }

    /**
     * Setter for id.
     *
     * @param value the value to set
     */
    public void setId(Long value) {
        entity.setId(value);
    }

    /**
     * Getter for title.
     *
     * @return value for title
     */
    @XmlElement
    public String getTitle() {
        return (expandLevel > 0) ? entity.getTitle() : null;
    }

    /**
     * Setter for title.
     *
     * @param value the value to set
     */
    public void setTitle(String value) {
        entity.setTitle(value);
    }

    /**
     * Getter for description.
     *
     * @return value for description
     */
    @XmlElement
    public String getDescription() {
        return (expandLevel > 0) ? entity.getDescription() : null;
    }

    /**
     * Setter for description.
     *
     * @param value the value to set
     */
    public void setDescription(String value) {
        entity.setDescription(value);
    }

    /**
     * Getter for initialPrice.
     *
     * @return value for initialPrice
     */
    @XmlElement
    public Double getInitialPrice() {
        return (expandLevel > 0) ? entity.getInitialPrice() : null;
    }

    /**
     * Setter for initialPrice.
     *
     * @param value the value to set
     */
    public void setInitialPrice(Double value) {
        entity.setInitialPrice(value);
    }

    /**
     * Getter for seller.
     *
     * @return value for seller
     */
    @XmlElement
    public SellerConverter getSeller() {
        if (expandLevel > 0) {
            if (entity.getSeller() != null) {
                return new SellerConverter(entity.getSeller(), uri.resolve("seller/"), expandLevel - 1, false);
            }
        }
        return null;
    }

    /**
     * Setter for seller.
     *
     * @param value the value to set
     */
    public void setSeller(SellerConverter value) {
        entity.setSeller((value != null) ? value.getEntity() : null);
    }

    /**
     * Returns the URI associated with this converter.
     *
     * @return the uri
     */
    @XmlAttribute
    public URI getUri() {
        return uri;
    }

    /**
     * Sets the URI for this reference converter.
     *
     */
    public void setUri(URI uri) {
        this.uri = uri;
    }

    /**
     * Returns the Item entity.
     *
     * @return an entity
     */
    @XmlTransient
    public Item getEntity() {
        if (entity.getId() == null) {
            ItemConverter converter = UriResolver.getInstance().resolve(ItemConverter.class, uri);
            if (converter != null) {
                entity = converter.getEntity();
            }
        }
        return entity;
    }

    /**
     * Returns the resolved Item entity.
     *
     * @return an resolved entity
     */
    public Item resolveEntity(EntityManager em) {
        List<Bid> bids = entity.getBids();
        List<Bid> newbids = new java.util.ArrayList<Bid>();
        if (bids != null) {
            for (Bid item : bids) {
                newbids.add(em.getReference(Bid.class, item.getId()));
            }
        }
        entity.setBids(newbids);
        Seller seller = entity.getSeller();
        if (seller != null) {
            entity.setSeller(em.getReference(Seller.class, seller.getId()));
        }
        return entity;
    }
}
