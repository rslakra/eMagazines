/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.bonbhel.oracle.auctionApp.converter;

import com.bonbhel.oracle.auctionApp.Bid;
import java.net.URI;
import java.util.Collection;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlAttribute;
import java.util.ArrayList;

/**
 *
 * @author bonbhejf
 */

@XmlRootElement(name = "bids")
public class BidsConverter {
    private Collection<Bid> entities;
    private Collection<BidConverter> items;
    private URI uri;
    private int expandLevel;
  
    /** Creates a new instance of BidsConverter */
    public BidsConverter() {
    }

    /**
     * Creates a new instance of BidsConverter.
     *
     * @param entities associated entities
     * @param uri associated uri
     * @param expandLevel indicates the number of levels the entity graph should be expanded
     */
    public BidsConverter(Collection<Bid> entities, URI uri, int expandLevel) {
        this.entities = entities;
        this.uri = uri;
        this.expandLevel = expandLevel;
        getBid();
    }

    /**
     * Returns a collection of BidConverter.
     *
     * @return a collection of BidConverter
     */
    @XmlElement
    public Collection<BidConverter> getBid() {
        if (items == null) {
            items = new ArrayList<BidConverter>();
        }
        if (entities != null) {
            items.clear();
            for (Bid entity : entities) {
                items.add(new BidConverter(entity, uri, expandLevel, true));
            }
        }
        return items;
    }

    /**
     * Sets a collection of BidConverter.
     *
     * @param a collection of BidConverter to set
     */
    public void setBid(Collection<BidConverter> items) {
        this.items = items;
    }

    /**
     * Returns the URI associated with this converter.
     *
     * @return the uri
     */
    @XmlAttribute
    public URI getUri() {
        return uri;
    }

    /**
     * Returns a collection Bid entities.
     *
     * @return a collection of Bid entities
     */
    @XmlTransient
    public Collection<Bid> getEntities() {
        entities = new ArrayList<Bid>();
        if (items != null) {
            for (BidConverter item : items) {
                entities.add(item.getEntity());
            }
        }
        return entities;
    }
}
