/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.bonbhel.oracle.auctionApp.converter;

import com.bonbhel.oracle.auctionApp.Item;
import java.net.URI;
import java.util.Collection;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlAttribute;
import java.util.ArrayList;

/**
 *
 * @author bonbhejf
 */

@XmlRootElement(name = "items")
public class ItemsConverter {
    private Collection<Item> entities;
    private Collection<ItemConverter> items;
    private URI uri;
    private int expandLevel;
  
    /** Creates a new instance of ItemsConverter */
    public ItemsConverter() {
    }

    /**
     * Creates a new instance of ItemsConverter.
     *
     * @param entities associated entities
     * @param uri associated uri
     * @param expandLevel indicates the number of levels the entity graph should be expanded
     */
    public ItemsConverter(Collection<Item> entities, URI uri, int expandLevel) {
        this.entities = entities;
        this.uri = uri;
        this.expandLevel = expandLevel;
        getItem();
    }

    /**
     * Returns a collection of ItemConverter.
     *
     * @return a collection of ItemConverter
     */
    @XmlElement
    public Collection<ItemConverter> getItem() {
        if (items == null) {
            items = new ArrayList<ItemConverter>();
        }
        if (entities != null) {
            items.clear();
            for (Item entity : entities) {
                items.add(new ItemConverter(entity, uri, expandLevel, true));
            }
        }
        return items;
    }

    /**
     * Sets a collection of ItemConverter.
     *
     * @param a collection of ItemConverter to set
     */
    public void setItem(Collection<ItemConverter> items) {
        this.items = items;
    }

    /**
     * Returns the URI associated with this converter.
     *
     * @return the uri
     */
    @XmlAttribute
    public URI getUri() {
        return uri;
    }

    /**
     * Returns a collection Item entities.
     *
     * @return a collection of Item entities
     */
    @XmlTransient
    public Collection<Item> getEntities() {
        entities = new ArrayList<Item>();
        if (items != null) {
            for (ItemConverter item : items) {
                entities.add(item.getEntity());
            }
        }
        return entities;
    }
}
