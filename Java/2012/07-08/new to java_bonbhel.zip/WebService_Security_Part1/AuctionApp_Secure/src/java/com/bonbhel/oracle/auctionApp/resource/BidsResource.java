/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.bonbhel.oracle.auctionApp.resource;

import com.bonbhel.oracle.auctionApp.Bid;
import java.util.Collection;
import javax.ws.rs.Path;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Produces;
import javax.ws.rs.Consumes;
import javax.ws.rs.PathParam;
import javax.ws.rs.QueryParam;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.persistence.EntityManager;
import com.bonbhel.oracle.auctionApp.Item;
import com.bonbhel.oracle.auctionApp.converter.BidsConverter;
import com.bonbhel.oracle.auctionApp.converter.BidConverter;
import javax.persistence.PersistenceContext;
import javax.ejb.Stateless;

/**
 *
 * @author bonbhejf
 */

@Path("/bids/")
@Stateless
public class BidsResource {
    @javax.ejb.EJB
    private BidResource bidResource;
    @Context
    protected UriInfo uriInfo;
    @PersistenceContext(unitName = "AuctionAppPU")
    protected EntityManager em;
  
    /** Creates a new instance of BidsResource */
    public BidsResource() {
    }

    /**
     * Get method for retrieving a collection of Bid instance in XML format.
     *
     * @return an instance of BidsConverter
     */
    @GET
    @Produces({"application/xml", "application/json"})
    public BidsConverter get(@QueryParam("start")
                             @DefaultValue("0")
    int start, @QueryParam("max")
               @DefaultValue("10")
    int max, @QueryParam("expandLevel")
             @DefaultValue("1")
    int expandLevel, @QueryParam("query")
                     @DefaultValue("SELECT e FROM Bid e")
    String query) {
        return new BidsConverter(getEntities(start, max, query), uriInfo.getAbsolutePath(), expandLevel);
    }

    /**
     * Post method for creating an instance of Bid using XML as the input format.
     *
     * @param data an BidConverter entity that is deserialized from an XML stream
     * @return an instance of BidConverter
     */
    @POST
    @Consumes({"application/xml", "application/json"})
    public Response post(BidConverter data) {
        Bid entity = data.resolveEntity(em);
        createEntity(data.resolveEntity(em));
        return Response.created(uriInfo.getAbsolutePath().resolve(entity.getId() + "/")).build();
    }

    /**
     * Returns a dynamic instance of BidResource used for entity navigation.
     *
     * @return an instance of BidResource
     */
    @Path("{id}/")
    public BidResource getBidResource(@PathParam("id")
    Long id) {
        bidResource.setId(id);
        bidResource.setEm(em);
        return bidResource;
    }

    /**
     * Returns all the entities associated with this resource.
     *
     * @return a collection of Bid instances
     */
    protected Collection<Bid> getEntities(int start, int max, String query) {
        return em.createQuery(query).setFirstResult(start).setMaxResults(max).getResultList();
    }

    /**
     * Persist the given entity.
     *
     * @param entity the entity to persist
     */
    protected void createEntity(Bid entity) {
        entity.setId(null);
        em.persist(entity);
        Item item = entity.getItem();
        if (item != null) {
            item.getBids().add(entity);
        }
    }
}
