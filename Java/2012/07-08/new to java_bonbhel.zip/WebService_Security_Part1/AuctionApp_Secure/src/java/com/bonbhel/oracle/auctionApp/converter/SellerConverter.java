/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.bonbhel.oracle.auctionApp.converter;

import com.bonbhel.oracle.auctionApp.Seller;
import java.net.URI;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlAttribute;
import javax.ws.rs.core.UriBuilder;
import javax.persistence.EntityManager;
import java.util.List;
import com.bonbhel.oracle.auctionApp.Item;

/**
 *
 * @author bonbhejf
 */

@XmlRootElement(name = "seller")
public class SellerConverter {
    private Seller entity;
    private URI uri;
    private int expandLevel;
  
    /** Creates a new instance of SellerConverter */
    public SellerConverter() {
        entity = new Seller();
    }

    /**
     * Creates a new instance of SellerConverter.
     *
     * @param entity associated entity
     * @param uri associated uri
     * @param expandLevel indicates the number of levels the entity graph should be expanded@param isUriExtendable indicates whether the uri can be extended
     */
    public SellerConverter(Seller entity, URI uri, int expandLevel, boolean isUriExtendable) {
        this.entity = entity;
        this.uri = (isUriExtendable) ? UriBuilder.fromUri(uri).path(entity.getId() + "/").build() : uri;
        this.expandLevel = expandLevel;
        getItems();
    }

    /**
     * Creates a new instance of SellerConverter.
     *
     * @param entity associated entity
     * @param uri associated uri
     * @param expandLevel indicates the number of levels the entity graph should be expanded
     */
    public SellerConverter(Seller entity, URI uri, int expandLevel) {
        this(entity, uri, expandLevel, false);
    }

    /**
     * Getter for items.
     *
     * @return value for items
     */
    @XmlElement
    public ItemsConverter getItems() {
        if (expandLevel > 0) {
            if (entity.getItems() != null) {
                return new ItemsConverter(entity.getItems(), uri.resolve("items/"), expandLevel - 1);
            }
        }
        return null;
    }

    /**
     * Setter for items.
     *
     * @param value the value to set
     */
    public void setItems(ItemsConverter value) {
        entity.setItems((value != null) ? new java.util.ArrayList<Item>(value.getEntities()) : null);
    }

    /**
     * Getter for id.
     *
     * @return value for id
     */
    @XmlElement
    public Long getId() {
        return (expandLevel > 0) ? entity.getId() : null;
    }

    /**
     * Setter for id.
     *
     * @param value the value to set
     */
    public void setId(Long value) {
        entity.setId(value);
    }

    /**
     * Getter for firstName.
     *
     * @return value for firstName
     */
    @XmlElement
    public String getFirstName() {
        return (expandLevel > 0) ? entity.getFirstName() : null;
    }

    /**
     * Setter for firstName.
     *
     * @param value the value to set
     */
    public void setFirstName(String value) {
        entity.setFirstName(value);
    }

    /**
     * Getter for lastName.
     *
     * @return value for lastName
     */
    @XmlElement
    public String getLastName() {
        return (expandLevel > 0) ? entity.getLastName() : null;
    }

    /**
     * Setter for lastName.
     *
     * @param value the value to set
     */
    public void setLastName(String value) {
        entity.setLastName(value);
    }

    /**
     * Returns the URI associated with this converter.
     *
     * @return the uri
     */
    @XmlAttribute
    public URI getUri() {
        return uri;
    }

    /**
     * Sets the URI for this reference converter.
     *
     */
    public void setUri(URI uri) {
        this.uri = uri;
    }

    /**
     * Returns the Seller entity.
     *
     * @return an entity
     */
    @XmlTransient
    public Seller getEntity() {
        if (entity.getId() == null) {
            SellerConverter converter = UriResolver.getInstance().resolve(SellerConverter.class, uri);
            if (converter != null) {
                entity = converter.getEntity();
            }
        }
        return entity;
    }

    /**
     * Returns the resolved Seller entity.
     *
     * @return an resolved entity
     */
    public Seller resolveEntity(EntityManager em) {
        List<Item> items = entity.getItems();
        List<Item> newitems = new java.util.ArrayList<Item>();
        if (items != null) {
            for (Item item : items) {
                newitems.add(em.getReference(Item.class, item.getId()));
            }
        }
        entity.setItems(newitems);
        return entity;
    }
}
