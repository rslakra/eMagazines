/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.bonbhel.oracle.auctionApp.converter;

import com.bonbhel.oracle.auctionApp.Seller;
import java.net.URI;
import java.util.Collection;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlAttribute;
import java.util.ArrayList;

/**
 *
 * @author bonbhejf
 */

@XmlRootElement(name = "sellers")
public class SellersConverter {
    private Collection<Seller> entities;
    private Collection<SellerConverter> items;
    private URI uri;
    private int expandLevel;
  
    /** Creates a new instance of SellersConverter */
    public SellersConverter() {
    }

    /**
     * Creates a new instance of SellersConverter.
     *
     * @param entities associated entities
     * @param uri associated uri
     * @param expandLevel indicates the number of levels the entity graph should be expanded
     */
    public SellersConverter(Collection<Seller> entities, URI uri, int expandLevel) {
        this.entities = entities;
        this.uri = uri;
        this.expandLevel = expandLevel;
        getSeller();
    }

    /**
     * Returns a collection of SellerConverter.
     *
     * @return a collection of SellerConverter
     */
    @XmlElement
    public Collection<SellerConverter> getSeller() {
        if (items == null) {
            items = new ArrayList<SellerConverter>();
        }
        if (entities != null) {
            items.clear();
            for (Seller entity : entities) {
                items.add(new SellerConverter(entity, uri, expandLevel, true));
            }
        }
        return items;
    }

    /**
     * Sets a collection of SellerConverter.
     *
     * @param a collection of SellerConverter to set
     */
    public void setSeller(Collection<SellerConverter> items) {
        this.items = items;
    }

    /**
     * Returns the URI associated with this converter.
     *
     * @return the uri
     */
    @XmlAttribute
    public URI getUri() {
        return uri;
    }

    /**
     * Returns a collection Seller entities.
     *
     * @return a collection of Seller entities
     */
    @XmlTransient
    public Collection<Seller> getEntities() {
        entities = new ArrayList<Seller>();
        if (items != null) {
            for (SellerConverter item : items) {
                entities.add(item.getEntity());
            }
        }
        return entities;
    }
}
