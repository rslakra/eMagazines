/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.bonbhel.oracle.auctionApp.resource;

import com.bonbhel.oracle.auctionApp.Item;
import java.util.Collection;
import javax.ws.rs.Path;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Produces;
import javax.ws.rs.Consumes;
import javax.ws.rs.PathParam;
import javax.ws.rs.QueryParam;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.persistence.EntityManager;
import com.bonbhel.oracle.auctionApp.Bid;
import com.bonbhel.oracle.auctionApp.Seller;
import com.bonbhel.oracle.auctionApp.converter.ItemsConverter;
import com.bonbhel.oracle.auctionApp.converter.ItemConverter;
import javax.persistence.PersistenceContext;
import javax.ejb.Stateless;

/**
 *
 * @author bonbhejf
 */

@Path("/items/")
@Stateless
public class ItemsResource {
    @javax.ejb.EJB
    private ItemResource itemResource;
    @Context
    protected UriInfo uriInfo;
    @PersistenceContext(unitName = "AuctionAppPU")
    protected EntityManager em;
  
    /** Creates a new instance of ItemsResource */
    public ItemsResource() {
    }

    /**
     * Get method for retrieving a collection of Item instance in XML format.
     *
     * @return an instance of ItemsConverter
     */
    @GET
    @Produces({"application/xml", "application/json"})
    public ItemsConverter get(@QueryParam("start")
                              @DefaultValue("0")
    int start, @QueryParam("max")
               @DefaultValue("10")
    int max, @QueryParam("expandLevel")
             @DefaultValue("1")
    int expandLevel, @QueryParam("query")
                     @DefaultValue("SELECT e FROM Item e")
    String query) {
        return new ItemsConverter(getEntities(start, max, query), uriInfo.getAbsolutePath(), expandLevel);
    }

    /**
     * Post method for creating an instance of Item using XML as the input format.
     *
     * @param data an ItemConverter entity that is deserialized from an XML stream
     * @return an instance of ItemConverter
     */
    @POST
    @Consumes({"application/xml", "application/json"})
    public Response post(ItemConverter data) {
        Item entity = data.resolveEntity(em);
        createEntity(data.resolveEntity(em));
        return Response.created(uriInfo.getAbsolutePath().resolve(entity.getId() + "/")).build();
    }

    /**
     * Returns a dynamic instance of ItemResource used for entity navigation.
     *
     * @return an instance of ItemResource
     */
    @Path("{id}/")
    public ItemResource getItemResource(@PathParam("id")
    Long id) {
        itemResource.setId(id);
        itemResource.setEm(em);
        return itemResource;
    }

    /**
     * Returns all the entities associated with this resource.
     *
     * @return a collection of Item instances
     */
    protected Collection<Item> getEntities(int start, int max, String query) {
        return em.createQuery(query).setFirstResult(start).setMaxResults(max).getResultList();
    }

    /**
     * Persist the given entity.
     *
     * @param entity the entity to persist
     */
    protected void createEntity(Item entity) {
        entity.setId(null);
        em.persist(entity);
        for (Bid value : entity.getBids()) {
            Item oldEntity = value.getItem();
            value.setItem(entity);
            if (oldEntity != null) {
                oldEntity.getBids().remove(value);
            }
        }
        Seller seller = entity.getSeller();
        if (seller != null) {
            seller.getItems().add(entity);
        }
    }
}
