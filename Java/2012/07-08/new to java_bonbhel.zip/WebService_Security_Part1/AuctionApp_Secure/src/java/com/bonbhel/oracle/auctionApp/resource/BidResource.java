/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.bonbhel.oracle.auctionApp.resource;

import com.bonbhel.oracle.auctionApp.Bid;
import javax.ws.rs.Path;
import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.DELETE;
import javax.ws.rs.Produces;
import javax.ws.rs.Consumes;
import javax.ws.rs.QueryParam;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.WebApplicationException;
import javax.persistence.NoResultException;
import javax.persistence.EntityManager;
import com.bonbhel.oracle.auctionApp.Item;
import com.bonbhel.oracle.auctionApp.converter.BidConverter;
import javax.ejb.Stateless;

/**
 *
 * @author bonbhejf
 */

@Stateless
public class BidResource {
    @javax.ejb.EJB
    private ItemResourceSub itemResourceSub;
    @Context
    protected UriInfo uriInfo;
    protected EntityManager em;
    protected Long id;
  
    /** Creates a new instance of BidResource */
    public BidResource() {
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setEm(EntityManager em) {
        this.em = em;
    }

    /**
     * Get method for retrieving an instance of Bid identified by id in XML format.
     *
     * @param id identifier for the entity
     * @return an instance of BidConverter
     */
    @GET
    @Produces({"application/xml", "application/json"})
    public BidConverter get(@QueryParam("expandLevel")
                            @DefaultValue("1")
    int expandLevel) {
        return new BidConverter(getEntity(), uriInfo.getAbsolutePath(), expandLevel);
    }

    /**
     * Put method for updating an instance of Bid identified by id using XML as the input format.
     *
     * @param id identifier for the entity
     * @param data an BidConverter entity that is deserialized from a XML stream
     */
    @PUT
    @Consumes({"application/xml", "application/json"})
    public void put(BidConverter data) {
        updateEntity(getEntity(), data.resolveEntity(em));
    }

    /**
     * Delete method for deleting an instance of Bid identified by id.
     *
     * @param id identifier for the entity
     */
    @DELETE
    public void delete() {
        deleteEntity(getEntity());
    }

    /**
     * Returns an instance of Bid identified by id.
     *
     * @param id identifier for the entity
     * @return an instance of Bid
     */
    protected Bid getEntity() {
        try {
            return (Bid) em.createQuery("SELECT e FROM Bid e where e.id = :id").setParameter("id", id).getSingleResult();
        } catch (NoResultException ex) {
            throw new WebApplicationException(new Throwable("Resource for " + uriInfo.getAbsolutePath() + " does not exist."), 404);
        }
    }

    /**
     * Updates entity using data from newEntity.
     *
     * @param entity the entity to update
     * @param newEntity the entity containing the new data
     * @return the updated entity
     */
    private Bid updateEntity(Bid entity, Bid newEntity) {
        Item item = entity.getItem();
        Item itemNew = newEntity.getItem();
        entity = em.merge(newEntity);
        if (item != null && !item.equals(itemNew)) {
            item.getBids().remove(entity);
        }
        if (itemNew != null && !itemNew.equals(item)) {
            itemNew.getBids().add(entity);
        }
        return entity;
    }

    /**
     * Deletes the entity.
     *
     * @param entity the entity to deletle
     */
    private void deleteEntity(Bid entity) {
        Item item = entity.getItem();
        if (item != null) {
            item.getBids().remove(entity);
        }
        em.remove(entity);
    }

    /**
     * Returns a dynamic instance of ItemResource used for entity navigation.
     *
     * @param id identifier for the parent entity
     * @return an instance of ItemResource
     */
    @Path("item/")
    public ItemResource getItemResource() {
        itemResourceSub.setParent(getEntity());
        return itemResourceSub;
    }

    @Stateless(name = "BidResource.ItemResourceSub")
    public static class ItemResourceSub extends ItemResource {

        private Bid parent;

        public void setParent(Bid parent) {
            this.parent = parent;
        }

        @Override
        protected Item getEntity() {
            Item entity = parent.getItem();
            if (entity == null) {
                throw new WebApplicationException(new Throwable("Resource for " + uriInfo.getAbsolutePath() + " does not exist."), 404);
            }
            return entity;
        }
    }
}
