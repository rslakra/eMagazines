/*
 * StopWatchNode.java - Node that expresses the stopwatch UI for 
 * the Lazy Init/Eval program
 * Developed by Jim Weaver to demonstrate lazy initialization and evaluation,
 * and custom binding, in JavaFX 2.0
 */
package javafxpert.lazyiniteval.ui;

import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonBuilder;
import javafx.scene.control.Label;
import javafx.scene.control.LabelBuilder;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.HBoxBuilder;
import javafx.scene.layout.VBox;
import javafxpert.lazyiniteval.binding.TimeStringBinding;
import javafxpert.lazyiniteval.model.StopWatchModel;

/**
 *
 * @author Jim Weaver
 */
public class StopWatchNode extends VBox {
  private StopWatchModel stopWatchModel;
  private Label nameNode;
  private Label elapsedNode;
  private Label lapNode;
  private Button startBtn;
  private Button stopBtn;
  private Button resetBtn;
  private Button lapBtn;
  
  private StringProperty elapsedTimeStrProperty = new SimpleStringProperty();
  
  public StopWatchNode() {
    stopWatchModel = new StopWatchModel();
    createStopWatchNode();
  }
  
  public StopWatchNode(String name) {
    stopWatchModel = new StopWatchModel(name);
    createStopWatchNode();
  }
  
  private void createStopWatchNode() {
    setId("stopwatchNode");
    getChildren().clear();
    
    nameNode = LabelBuilder.create()
      .text("Name: " + stopWatchModel.getName())
      .build();
    
    elapsedNode = LabelBuilder.create()
      .id("stopwatchLabels")
      .onMouseClicked(new EventHandler<MouseEvent>() {
        public void handle(MouseEvent me) {
          if (elapsedNode.textProperty().isBound()) {
            elapsedNode.textProperty().unbind();
          }
          else {
            elapsedNode.textProperty().bind(elapsedTimeStrProperty);
          }
        }
      })
      .build();
    
    lapNode = LabelBuilder.create()
      .build();
    
    startBtn = ButtonBuilder.create()
      .text("Start")
      .onAction(new EventHandler<ActionEvent>() {
        @Override public void handle(ActionEvent e) {
          stopWatchModel.start();
        }
      })
      .build();
    
    stopBtn = ButtonBuilder.create()
      .text("Stop")
      .onAction(new EventHandler<ActionEvent>() {
        @Override public void handle(ActionEvent e) {
          stopWatchModel.stop();
        }
      })
      .build();
    
    lapBtn = ButtonBuilder.create()
      .text("Lap")
      .onAction(new EventHandler<ActionEvent>() {
        @Override public void handle(ActionEvent e) {
          stopWatchModel.lap();
          if (!lapNode.textProperty().isBound()) {
            lapNode.textProperty().bind(
              new TimeStringBinding(stopWatchModel.lapMillisProperty())
            );
          }
        }
      })
      .build();
    
    resetBtn = ButtonBuilder.create()
      .text("Reset")
      .onAction(new EventHandler<ActionEvent>() {
        @Override public void handle(ActionEvent e) {
          stopWatchModel.reset();
        }
      })
      .build();
    
    HBox elapsedPane = HBoxBuilder.create()
      .spacing(5)
      .children(
        LabelBuilder.create()
          .text("Elapsed time:")
          .build(),
        elapsedNode
      )
      .build();
    
    HBox lapPane = HBoxBuilder.create()
      .spacing(5)
      .children(
        new Label("Lap time:"),
        lapNode
      )
      .build();
    
    HBox buttonPane = HBoxBuilder.create()
      .spacing(5)
      .children(
        startBtn,
        stopBtn,
        lapBtn,
        resetBtn
      )
      .build();
    
    getChildren().add(nameNode);
    getChildren().add(elapsedPane);
    getChildren().add(lapPane);
    getChildren().add(buttonPane);
    
    elapsedTimeStrProperty.addListener(new InvalidationListener() {
      public void invalidated(Observable observable) {
        if (!elapsedNode.textProperty().isBound()) {
          elapsedNode.setText("invalidated - click to bind/unbind");
        }
      }
    });
    
    elapsedTimeStrProperty.bind(
      new TimeStringBinding(
        stopWatchModel.elapsedMillisProperty()
      )
    );
    
    // Next lines commented to the TimeStringBinding custom binding instead
    //elapsedTimeStrProperty.bind(
    //  stopWatchModel.elapsedMillisProperty().asString()
    //);
  }
}
