/*
 * StopWatchModel.java - Node that expresses the stopwatch model for 
 * the Lazy Init/Eval program
 * Developed by Jim Weaver to demonstrate lazy initialization and evaluation,
 * and custom binding, in JavaFX 2.0
 */
package javafxpert.lazyiniteval.model;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.animation.TimelineBuilder;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.util.Duration;

/**
 * A JavaFX bean that contains properties and methods relevant to a stopwatch instance
 */
public final class StopWatchModel {
  public StopWatchModel(String name) {
    setName(name);
  }
  
  public StopWatchModel() {}    
  
  // Full-lazy initialization strategy
  private static final String DEFAULT_NAME = "Default";
  private StringProperty name;
  private String nameStr = DEFAULT_NAME;
  final public void setName(String value) { 
    if (name != null) {
      name.set(value);
    }
    else {
      nameStr = value;
    }
  }
  final public String getName() { 
    if (name != null) {
      return name.get();
    }
    else {
      return nameStr;
    }
  }
  final public StringProperty nameProperty() { 
    if (name == null) {
      System.out.println("Instantiating name StringProperty");
      name = new SimpleStringProperty(this, "name", DEFAULT_NAME);
    }
    return name; 
  }

  private IntegerProperty elapsedMillis;
  final public void setElapsedMillis(int value) { 
    elapsedMillisProperty().set(value); 
  }
  final public int getElapsedMillis() { 
    return elapsedMillisProperty().get(); 
  }
  final public IntegerProperty elapsedMillisProperty() { 
    if (elapsedMillis == null) {
      System.out.println("Instantiating elapsedMillis IntegerProperty for " 
                          + getName());
      elapsedMillis = new SimpleIntegerProperty(this, "elapsedMillis");
    }
    return elapsedMillis; 
  }
  
  // Half-lazy initialization strategy
  private static final int DEFAULT_LAP_MILLIS = 0;
  private IntegerProperty lapMillis;
  final public void setLapMillis(int value) { 
    if ((lapMillis != null) || (value != DEFAULT_LAP_MILLIS)) {
      lapMillisProperty().set(value);
    }
  }
  final public int getLapMillis() { 
    if (lapMillis != null) {
      return lapMillis.get();
    }
    else {
      return DEFAULT_LAP_MILLIS;
    }
  }
  final public IntegerProperty lapMillisProperty() { 
    if (lapMillis == null) {
      System.out.println("Instantiating lapMillis IntegerProperty for " 
                         + getName());
      lapMillis = new SimpleIntegerProperty(this, "lapMillis", DEFAULT_LAP_MILLIS);
    }
    return lapMillis; 
  }
  
  private Timeline timer;
  
  private void createTimeline() {
    if (timer == null) {
      System.out.println("Creating timer Timeline for " + getName());
      timer = TimelineBuilder.create()
        .keyFrames(
          new KeyFrame(
            new Duration(1.0),
            new EventHandler<ActionEvent>() {
              public void handle(javafx.event.ActionEvent t) {
                elapsedMillis.set(elapsedMillis.get() + 1);
              }
            }
          )
        )
        .cycleCount(Timeline.INDEFINITE)
        .build();
    }
  }
  
  public void start() {
    createTimeline();
    timer.playFromStart();
  }

  public void stop() {
    createTimeline();
    timer.stop();
  }

  public void lap() {
    setLapMillis(getElapsedMillis());
  }

  public void reset() {
    setElapsedMillis(0);
    setLapMillis(0);
  }

  public String toString() {
    return name.getValue();
  }
}
