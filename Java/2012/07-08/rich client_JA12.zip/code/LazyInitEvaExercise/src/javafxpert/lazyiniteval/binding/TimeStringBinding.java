/*
 * TimeStringBinding.java - Class that defines a custom binding for 
 * the Lazy Init/Eval program
 * Developed by Jim Weaver to demonstrate lazy initialization and evaluation,
 * and custom binding, in JavaFX 2.0
 */
package javafxpert.lazyiniteval.binding;

import java.text.SimpleDateFormat;
import javafx.beans.binding.StringBinding;
import javafx.beans.property.IntegerProperty;

public class TimeStringBinding extends StringBinding {
  private SimpleDateFormat timeFormat = new SimpleDateFormat("mm:ss:SSS");
  private IntegerProperty millis;
  
  public TimeStringBinding(IntegerProperty millisArg) {
    super.bind(millisArg);
    millis = millisArg;
  }
  
  @Override
  protected String computeValue() {
    int elapsedInt = millis.get();
    return timeFormat.format(elapsedInt);
  }
}
