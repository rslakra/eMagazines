/*
 * StopWatchModel.java - Node that expresses the stopwatch model for 
 * the Lazy Init/Eval program
 * Developed by Jim Weaver to demonstrate lazy initialization and evaluation,
 * and custom binding, in JavaFX 2.0
 */
package javafxpert.lazyiniteval.model;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.animation.TimelineBuilder;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.util.Duration;

/**
 * A JavaFX bean that contains properties and methods relevant to a stopwatch instance
 */
public final class StopWatchModel {
  public StopWatchModel(String name) {
    setName(name);
  }
  
  public StopWatchModel() {}    
  
  // TO DO: Implement a full-lazy initialization strategy 
  //        for the name property
  private StringProperty name;
  final public void setName(String value) { 
    nameProperty().set(value); 
  }
  final public String getName() { 
    return nameProperty().get();
  }
  final public StringProperty nameProperty() { 
    if (name == null) {
      System.out.println("Instantiating name StringProperty");
      name = new SimpleStringProperty(this, "name", "Default");
    }
    return name; 
  }

  private IntegerProperty elapsedMillis;
  final public void setElapsedMillis(int value) { 
    elapsedMillisProperty().set(value); 
  }
  final public int getElapsedMillis() { 
    return elapsedMillisProperty().get(); 
  }
  final public IntegerProperty elapsedMillisProperty() { 
    if (elapsedMillis == null) {
      System.out.println("Instantiating elapsedMillis IntegerProperty for " 
                          + getName());
      elapsedMillis = new SimpleIntegerProperty(this, "elapsedMillis");
    }
    return elapsedMillis; 
  }
  
  // TO DO: Implement a half-lazy initialization strategy 
  //        for the lapMillis property
  private IntegerProperty lapMillis;
  final public void setLapMillis(int value) { 
    lapMillisProperty().set(value); 
  }
  final public int getLapMillis() { 
    return lapMillisProperty().get(); 
  }
  final public IntegerProperty lapMillisProperty() { 
    if (lapMillis == null) {
      System.out.println("Instantiating lapMillis IntegerProperty for " 
                         + getName());
      lapMillis = new SimpleIntegerProperty(this, "lapMillis");
    }
    return lapMillis; 
  }
  
  private Timeline timer;
  
  private void createTimeline() {
    if (timer == null) {
      System.out.println("Creating timer Timeline for " + getName());
      timer = TimelineBuilder.create()
        .keyFrames(
          new KeyFrame(
            new Duration(1.0),
            new EventHandler<ActionEvent>() {
              public void handle(javafx.event.ActionEvent t) {
                elapsedMillis.set(elapsedMillis.get() + 1);
              }
            }
          )
        )
        .cycleCount(Timeline.INDEFINITE)
        .build();
    }
  }
  
  public void start() {
    createTimeline();
    timer.playFromStart();
  }

  public void stop() {
    createTimeline();
    timer.stop();
  }

  public void lap() {
    setLapMillis(getElapsedMillis());
  }

  public void reset() {
    setElapsedMillis(0);
    setLapMillis(0);
  }

  public String toString() {
    return name.getValue();
  }
}
