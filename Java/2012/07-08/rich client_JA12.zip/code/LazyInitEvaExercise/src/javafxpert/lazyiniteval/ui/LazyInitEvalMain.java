/*
 * LazyInitEvalMain.java - Main class for the Lazy Init/Eval program
 * Developed by Jim Weaver to demonstrate lazy initialization and evaluation,
 * and custom binding, in JavaFX 2.0
 */
package javafxpert.lazyiniteval.ui;

import javafx.application.Application;
import javafx.scene.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class LazyInitEvalMain extends Application {
      
  public static void main(String[] args) {
    Application.launch(args);
  }
    
  @Override public void start(final Stage primaryStage) {
    Scene scene = SceneBuilder.create()
      .width(360)
      .height(420)
      .stylesheets("javafxpert/lazyiniteval/ui/lazyiniteval.css")
      .root(
        VBoxBuilder.create()
          .id("rootNode")
          .spacing(30)
          .children(
            new StopWatchNode("First"),
            new StopWatchNode("Second"),
            new StopWatchNode()
          )
          .build()
      )
      .build();
    
    primaryStage.setScene(scene);
    primaryStage.setTitle("Lazy Initialization and Evaluation Example");
    primaryStage.show();
  }      
}
