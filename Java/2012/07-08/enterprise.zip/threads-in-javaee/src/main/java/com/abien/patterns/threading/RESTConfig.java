package com.abien.patterns.threading;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

/**
 *
 * @author adam bien, adam-bien.com
 */
@ApplicationPath("resources")
public class RESTConfig extends Application{
    
}
