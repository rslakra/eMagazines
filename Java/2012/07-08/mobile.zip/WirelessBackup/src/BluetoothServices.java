
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Enumeration;
import java.util.Hashtable;
import javax.bluetooth.DeviceClass;
import javax.bluetooth.DiscoveryAgent;
import javax.bluetooth.DiscoveryListener;
import javax.bluetooth.LocalDevice;
import javax.bluetooth.RemoteDevice;
import javax.bluetooth.ServiceRecord;
import javax.bluetooth.UUID;
import javax.microedition.io.Connector;
import javax.microedition.lcdui.Alert;
import javax.microedition.lcdui.AlertType;
import javax.microedition.lcdui.Choice;
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.Form;
import javax.microedition.lcdui.Gauge;
import javax.microedition.lcdui.List;
import javax.microedition.rms.RecordStore;
import javax.microedition.rms.RecordStoreException;
import javax.obex.ClientSession;
import javax.obex.HeaderSet;
import javax.obex.Operation;
import javax.obex.ResponseCodes;

public class BluetoothServices implements DiscoveryListener, CommandListener {
  
  private Display display;
  private List list;
  
  private Form workingForm;
  private Gauge working;
  private Alert nothing;
  private Alert msg;
  
  private Command searchCommand    = null;
  private Command backCommand      = null; 
  private Command storeCommand     = null;
  
  // the discovery agent
  DiscoveryAgent agent = null;  
  
  // the list of devices
  private List listofDevices = null;

  // the list of services
  private List listofServices = null;

  // a hashtable to hold the discovered devices and their bluetooth address
  private Hashtable devices;

  // a hashtable to hold the discovered services and their connection url
  private Hashtable services;
  private RecordStore rs;
          
  public BluetoothServices(Display display, List list) {
    
    this.display = display;
    this.list = list;
    
    workingForm = new Form("Please wait..");    
    working =
      new Gauge("Working", false, Gauge.INDEFINITE, Gauge.CONTINUOUS_RUNNING);
    workingForm.append(working);
    nothing = new Alert("Message", "Nothing found!", null, AlertType.ERROR);
    msg = new Alert("Message", "Done!", null, AlertType.INFO);
    
    devices = new Hashtable();
    services = new Hashtable();

    // initialize the UI

    // list of devices
    listofDevices = new List("Devices Found", Choice.IMPLICIT);
    
    // list of services
    listofServices = new List("Services Found", Choice.IMPLICIT);  
    
    backCommand = new Command("Back", Command.BACK, 1);
    searchCommand = new Command("Search", Command.SCREEN, 1);   
    storeCommand = new Command("Store", Command.SCREEN, 1); 
    
    listofDevices.addCommand(backCommand);
    listofDevices.addCommand(searchCommand);

    listofDevices.setCommandListener(this);

    listofServices.addCommand(backCommand);
    listofServices.addCommand(storeCommand);

    listofServices.setCommandListener(this);
    
    
  }

  void findDevices() {

    // remove any previous devices discovered from the list
    listofDevices.deleteAll();
    devices.clear(); // clear from the hashtable as well

    try {

      // get the local discovery agent
      agent = LocalDevice.getLocalDevice().getDiscoveryAgent();

      // start the inquiry for general unlimited inquiry
      agent.startInquiry(DiscoveryAgent.GIAC, this);

      // and show a working figure to the user
      display.setCurrent(workingForm);

    } catch(Exception ex) {
      handleError(ex);
    }
  }

  // searches for services for a device
  private void doSearchServices() {

    // clear any previous services
    listofServices.deleteAll();
    services.clear(); // clear from the hashtable as well

    // get the device out of the hashtable
    RemoteDevice device =
      (RemoteDevice)devices.get(
        (new Long(listofDevices.getSelectedIndex() + 1)));

    try {

      // next look for services for this device
      agent.searchServices(
        null,
        new UUID[] {new UUID(0x1105L)}, // we want the OBEX PUSH Profile
        device,
        this);

      // and show a working figure to the user
      display.setCurrent(workingForm);

    } catch(Exception ex) {
      handleError(ex);
    }


  }

  // as devices are discovered, add them to the list
  public void deviceDiscovered(RemoteDevice btDevice, DeviceClass cod) {

    try {      

      // add the devices using the friendly names
      listofDevices.append(btDevice.getFriendlyName(false), null);

      // add to the devices hashtable
      devices.put(new Long(listofDevices.size()), btDevice);

    } catch(Exception ex) { handleError(ex); }
  }

  // as services are discovered, add them to the services list
  public void servicesDiscovered(int transID, ServiceRecord[] servRecord) {
    
    for (int i = 0; i < servRecord.length; i++) {
      
      // add the services URL to the display and the hashtable
      String connURL = servRecord[i].getConnectionURL(
            ServiceRecord.NOAUTHENTICATE_NOENCRYPT, false);    

      listofServices.append(connURL, null);
      
      services.put(new Long(listofServices.size()), connURL);     

    }
    
  }

  public void serviceSearchCompleted(int transID, int respCode) {

    // once the service search is completed, show the list of services
    // if any were found
    if(listofServices.size() == 0) {
      display.setCurrent(nothing, list);
    } else {
      display.setCurrent(listofServices);
    }   
    
  }

  // for compactness, I have ignored the discType parameter. This parameter
  // would indicate if a search was successfully completed or not. If it returns
  // DiscoveryListner.INQUIRY_COMPLETED, then the search was successful,
  // INQUIRY_TERMINATED if the user cancels the search and INQUIRY_ERROR if
  // there is an error.
  public void inquiryCompleted(int discType) {

    // once the inquiry is completed, show the list of devices to the user
    if(listofDevices.size() == 0) {
      display.setCurrent(nothing, list);
    } else {
      display.setCurrent(listofDevices);      
    }
  }
  
  // method to send data to the selected discovered service
  void doSend(String connURL, String fileName, ByteArrayOutputStream b) {

    try {

      // open a client session
      ClientSession clientSession =
        (ClientSession) Connector.open(connURL);

      // connect using no headers
      HeaderSet rHeaders = clientSession.connect(null);

      if(rHeaders.getResponseCode() != ResponseCodes.OBEX_HTTP_OK) {
        // the connection could not be established
        handleError(
          new Exception("Remote client returned invalid response code: " +
            rHeaders.getResponseCode()));
        return;
      }

      // if we are here, then response code was ok
      
      // create a new set of headers
      HeaderSet headers = clientSession.createHeaderSet();
      headers.setHeader(HeaderSet.NAME, fileName);
      headers.setHeader(HeaderSet.TYPE, "binary");

      // create an operation using the headers we have just created
      Operation op = clientSession.put(headers);

      // on this operation, create the output stream
      OutputStream out = op.openOutputStream();

      // and send the data
       out.write(b.toByteArray());

      // finish by closing the stream and the operation
      out.close();
      op.close();
      clientSession.disconnect(null);

    } catch (Exception ex) {
      handleError(ex);
    }
  }  
  
  // handles errors
  private void handleError(Exception ex) {
    display.setCurrent(
      new Alert("Error!", ex.getMessage(), null, AlertType.ERROR));
    ex.printStackTrace();
  }

  public void commandAction(Command cmd, Displayable disp) {

    // handle the back command
    if(cmd == backCommand) {
      display.setCurrent(list);
    }

    // handle the search command
    if(cmd == searchCommand) {
        doSearchServices();
    }

    // send the note to the specified service on the specified device
    if(cmd == storeCommand) {
      doStore();
    }

  }

  private void doStore() {
    try {
      rs = RecordStore.openRecordStore("Backup Store", true);
      
      // get the connection URL out of the hashtable
      String connURL =
        (String) services.get(
          new Long(listofServices.getSelectedIndex() + 1));
      
      rs.addRecord(connURL.getBytes(), 0, connURL.length());
      
      display.setCurrent(msg, list);
      
    } catch(Exception ex) {
      handleError(ex);
    }
  }
  
}
