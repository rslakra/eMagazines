package com.lodgon.javafx;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.ListView;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TableView;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import org.javafxdata.datasources.reader.DataSourceReader;
import org.javafxdata.datasources.reader.RestRequestBuilder;
import org.javafxdata.datasources.provider.ObjectDataSource;
import org.javafxdata.datasources.provider.ObjectDataSourceBuilder;


public class TwitterApp extends Application {

  
  final ObservableList<Tweet> allTweets = FXCollections.observableArrayList();
  ObjectDataSource dataSource;

  public static void main(String[] args) {
    launch(args);
  }

  @Override
  public void start(Stage stage) {
    stage.setTitle("DataFX Samples");
    final Scene scene = new Scene(new Group(), 875, 700);
    scene.setFill(Color.LIGHTGRAY);
    Group root = (Group) scene.getRoot();
    dataSource = createDataSource();
    root.getChildren().add(getContent(scene));

    stage.setScene(scene);
    stage.show();
    dataSource.retrieve();

  }

  public Node getContent(Scene scene) {
    // TabPane
    final TabPane tabPane = new TabPane();
    tabPane.setTabClosingPolicy(TabPane.TabClosingPolicy.UNAVAILABLE);
    tabPane.setPrefWidth(scene.getWidth());
    tabPane.setPrefHeight(scene.getHeight());

    tabPane.prefWidthProperty().bind(scene.widthProperty());
    tabPane.prefHeightProperty().bind(scene.heightProperty());

    Tab listTab = new Tab("list");
    buildListTab(listTab);
    tabPane.getTabs().add(listTab);

    Tab tableTab = new Tab("table");
    buildTableTab(tableTab);
    tabPane.getTabs().add(tableTab);

    return tabPane;
  }

  void buildListTab(Tab t) {
    ListView listView = new ListView(allTweets);
    t.setContent(listView);
  }

  void buildTableTab(Tab t) {
    TableView tableView = new TableView(allTweets);
    t.setContent(tableView);
    tableView.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
    tableView.getColumns().addAll(dataSource.getColumns());
  }

  ObjectDataSource createDataSource() {
    RestRequestBuilder rrb = new RestRequestBuilder("http://search.twitter.com")
            .path("search.rss")
            .queryParam("q", "javafx");
    DataSourceReader dataSourceReader = rrb.build();
    ObjectDataSourceBuilder<Tweet> builder =
            ObjectDataSourceBuilder.<Tweet>create();
    builder.itemClass(Tweet.class)
            .dataSourceReader(dataSourceReader)
            .itemTag("item")
            .resultList(allTweets)
            .columns("author", "title");
    ObjectDataSource dataSource = builder.build();
    return dataSource;
  }
}
