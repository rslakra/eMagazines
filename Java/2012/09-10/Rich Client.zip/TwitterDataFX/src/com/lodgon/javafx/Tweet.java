package com.lodgon.javafx;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 *
 * @author johan
 */
public class Tweet {
  
  private StringProperty titleProperty = new SimpleStringProperty();
  private StringProperty authorProperty = new SimpleStringProperty();
  private StringProperty pubDateProperty = new SimpleStringProperty();

  public String getTitle() {
    return titleProperty.get();
  }

  public void setTitle(String title) {
    this.titleProperty.set(title);
  }

  public StringProperty titleProperty() {
    return titleProperty;
  }
  
  public String getAuthor() {
    return authorProperty.get();
  }
  
  public void setAuthor(String author) {
    this.authorProperty.set(author);
  }
  
  public StringProperty authorProperty() {
    return authorProperty;
  }
  
    public String getPubDate() {
        return pubDateProperty.get();
    }

    public void setPubDate(String date) {
        this.pubDateProperty.set(date);
    }
    
    public StringProperty pubDateProperty() {
      return pubDateProperty;
    }
    
    @Override
    public String toString() {
        return getPubDate() + "-" + getAuthor() + ": " + getTitle();
    }

}
