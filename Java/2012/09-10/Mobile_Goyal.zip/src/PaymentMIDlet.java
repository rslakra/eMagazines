import com.sun.lwuit.events.ActionEvent;
import javax.microedition.midlet.MIDlet;
import javax.microedition.payment.TransactionListener;
import javax.microedition.payment.TransactionModule;
import javax.microedition.payment.TransactionModuleException;
import javax.microedition.payment.TransactionRecord;
import com.sun.lwuit.*;
import com.sun.lwuit.events.ActionListener;
import com.sun.lwuit.layouts.GridLayout;
import com.sun.lwuit.plaf.UIManager;
import com.sun.lwuit.util.Resources;
import java.io.IOException;


public class PaymentMIDlet extends MIDlet 
  implements ActionListener, TransactionListener {
  
  // the display items
  private Command exitCommand = null;
  private Command goCommand   = null;
  private Form form;
  private ComboBox selection;
  
  // the transaction module
  private TransactionModule module;
  
  public PaymentMIDlet() {
    Display.init(this);
    
    // set up the theme as one of the default themes
    try {
      Resources r = Resources.open("/theme1.res");
      UIManager.getInstance().setThemeProps(r.getTheme("Theme 1"));
    } catch (IOException ioe) {
      ioe.printStackTrace();
    }    
    
    form = new Form("Payment Demo");
    form.setLayout(new GridLayout(2, 1));
    
    exitCommand = new Command("Exit");
    goCommand   = new Command("Go");
    
    form.addComponent(new Label("Make A Donation: "));
    selection = new ComboBox(new String[] {"$5 Donation", "$10 Donation"});
    form.addComponent(selection);
    
    form.addCommand(exitCommand);
    form.addCommand(goCommand);
    form.addCommandListener(this);
    
    // set up the transaction module
    try {
      module = new TransactionModule(this);
      module.setListener(this);
    } catch(TransactionModuleException ex) {
      handleError(ex);
    }

  }

  public void startApp() {
    form.show();
  }
  
  public void pauseApp() {
  }
  
  public void destroyApp(boolean unconditional) {
  }
  
  // handles errors
  private void handleError(Exception ex) {
    Dialog.show("Error", ex.getMessage(), "OK", null);
    ex.printStackTrace();
  }

  public void processed(TransactionRecord tr) {

    // let us first notify the waiting thread that we can proceed
    synchronized(this) {
      notify();
    }
    
    // now based on the state of the transaction record, setup the message    
    switch(tr.getState()) {
      case TransactionRecord.TRANSACTION_SUCCESSFUL: {
        Dialog.show("Great!", "WOW! You are generous. Thank you!", "OK", null);
        break;
      }
      case TransactionRecord.TRANSACTION_REJECTED: {
        Dialog.show("Hmm!", "Why? Got cold feet?", "OK", null);
        break;
      }
      case TransactionRecord.TRANSACTION_FAILED: 
      default: {
        Dialog.show("Oh No!", "Looks like today is not a good day. Technical " +
          "problems. Sorry! Transaction not done", "OK", null);
        break;
      } 
    }    
    
  }

  public void actionPerformed(ActionEvent ae) {  
    
    // first the exit command
    if(ae.getCommand() == exitCommand) {
      destroyApp(true);
      notifyDestroyed();          
      return;
    } else {
      
      // can only be the "go" command
      try {
        int selectedId = selection.getSelectedIndex(); // what was selected
        
        // process it
        module.process(
          selectedId,
          "Donate " + (selectedId == 0 ? "$5.00" : "$10.00"), 
          "Would you like to donate " + (selectedId == 0 ? "$5.00" : "$10.00") +
          " to Vikram's Charity?");
        
        // and then wait.... till we get notified that the payment is processed
        synchronized(this) {
          try {
            wait();
          } catch(InterruptedException ie) {            
          }
        }
      } catch(Exception ex) {
        handleError(ex);
      }
    }
  }
  
}
